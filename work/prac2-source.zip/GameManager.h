#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H

#include <string>

#include "Traveller.h"
#include "MoveState.h"
#include "Trip.h"
#include "RouteStrategy.h"
#include "MapComponent.h"
#include "Decorator.h"
#include "WorldBuilder.h"
#include "WorldProduct.h"

class GameManager {
private:
    int mode;
    std::string routeType;
    Traveller* player;
    Trip* trip;
    Region* worldMap;
    WorldBuilder* currentBiomeFactory;
    Location* activeLocation;

public:
    GameManager();
    virtual ~GameManager();

    void build();
    void move();
    void plan();
    void* makeThing(std::string biome, std::string kind);
    void run();

    // Biome injection methods used by test suites
    void setBiome(WorldBuilder* builder);
    void enterBiome();
};

#endif