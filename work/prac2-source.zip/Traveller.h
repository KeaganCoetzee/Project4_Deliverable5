#ifndef TRAVELLER_H
#define TRAVELLER_H
#include "MoveState.h"
#include <string>

class MoveState;
class Location;

class Traveller {
private:
    MoveState* currentState;
    Location* currentLocation;

public:
    Traveller(MoveState* initState);
    virtual ~Traveller();
    
    void move();
    bool changeState(MoveState* newState);
    std::string getCurrentModeName();
    
    Location* getCurrentLocation();
    void setCurrentLocation(Location* loc);
};

#endif