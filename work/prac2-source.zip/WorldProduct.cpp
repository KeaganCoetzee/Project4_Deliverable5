#include "WorldProduct.h"
#include <iostream>

// ---------- Desert Family ----------
void DesertNPC::print() const {
    std::cout << "Desert NPC: " << name << std::endl;
}
void DesertTerrain::print() const {
    std::cout << "Desert Terrain: " << name << std::endl;
}
void DesertObstacle::print() const {
    std::cout << "Desert Obstacle: " << name << std::endl;
}

// ---------- Ocean Family ----------
void OceanNPC::print() const {
    std::cout << "Ocean NPC: " << name << std::endl;
}
void OceanTerrain::print() const {
    std::cout << "Ocean Terrain: " << name << std::endl;
}
void OceanObstacle::print() const {
    std::cout << "Ocean Obstacle: " << name << std::endl;
}

// ---------- Forest Family ----------
void ForestNPC::print() const {
    std::cout << "Forest NPC: " << name << std::endl;
}
void ForestTerrain::print() const {
    std::cout << "Forest Terrain: " << name << std::endl;
}
void ForestObstacle::print() const {
    std::cout << "Forest Obstacle: " << name << std::endl;
}

// ---------- Snow Family ----------
void SnowNPC::print() const {
    std::cout << "Snow NPC: " << name << std::endl;
}
void SnowTerrain::print() const {
    std::cout << "Snow Terrain: " << name << std::endl;
}
void SnowObstacle::print() const {
    std::cout << "Snow Obstacle: " << name << std::endl;
}

// ---------- City Family ----------
void CityNPC::print() const {
    std::cout << "City NPC: " << name << std::endl;
}
void CityTerrain::print() const {
    std::cout << "City Terrain: " << name << std::endl;
}
void CityObstacle::print() const {
    std::cout << "City Obstacle: " << name << std::endl;
}