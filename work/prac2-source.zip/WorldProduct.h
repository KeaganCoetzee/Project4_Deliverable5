#ifndef WORLDPRODUCTS_H
#define WORLDPRODUCTS_H

#include <string>

// ---------- Abstract Products ----------

class NPCProduct {
public:
    virtual void print() const = 0;
    virtual ~NPCProduct() = default;
};

class TerrainProduct {
public:
    virtual void print() const = 0;
    virtual ~TerrainProduct() = default;
};

class ObstacleProduct {
public:
    virtual void print() const = 0;
    virtual ~ObstacleProduct() = default;
};

// ---------- Desert Family ----------

class DesertNPC : public NPCProduct {
private:
    std::string name;
public:
    explicit DesertNPC(const std::string& n) : name(n) {}
    void print() const override;
};

class DesertTerrain : public TerrainProduct {
private:
    std::string name;
public:
    explicit DesertTerrain(const std::string& n) : name(n) {}
    void print() const override;
};

class DesertObstacle : public ObstacleProduct {
private:
    std::string name;
public:
    explicit DesertObstacle(const std::string& n) : name(n) {}
    void print() const override;
};

// ---------- Ocean Family ----------

class OceanNPC : public NPCProduct {
private:
    std::string name;
public:
    explicit OceanNPC(const std::string& n) : name(n) {}
    void print() const override;
};

class OceanTerrain : public TerrainProduct {
private:
    std::string name;
public:
    explicit OceanTerrain(const std::string& n) : name(n) {}
    void print() const override;
};

class OceanObstacle : public ObstacleProduct {
private:
    std::string name;
public:
    explicit OceanObstacle(const std::string& n) : name(n) {}
    void print() const override;
};

// ---------- Forest Family ----------

class ForestNPC : public NPCProduct {
private:
    std::string name;
public:
    explicit ForestNPC(const std::string& n) : name(n) {}
    void print() const override;
};

class ForestTerrain : public TerrainProduct {
private:
    std::string name;
public:
    explicit ForestTerrain(const std::string& n) : name(n) {}
    void print() const override;
};

class ForestObstacle : public ObstacleProduct {
private:
    std::string name;
public:
    explicit ForestObstacle(const std::string& n) : name(n) {}
    void print() const override;
};

// ---------- Snow Family ----------

class SnowNPC : public NPCProduct {
private:
    std::string name;
public:
    explicit SnowNPC(const std::string& n) : name(n) {}
    void print() const override;
};

class SnowTerrain : public TerrainProduct {
private:
    std::string name;
public:
    explicit SnowTerrain(const std::string& n) : name(n) {}
    void print() const override;
};

class SnowObstacle : public ObstacleProduct {
private:
    std::string name;
public:
    explicit SnowObstacle(const std::string& n) : name(n) {}
    void print() const override;
};

// ---------- City Family ----------

class CityNPC : public NPCProduct {
private:
    std::string name;
public:
    explicit CityNPC(const std::string& n) : name(n) {}
    void print() const override;
};

class CityTerrain : public TerrainProduct {
private:
    std::string name;
public:
    explicit CityTerrain(const std::string& n) : name(n) {}
    void print() const override;
};

class CityObstacle : public ObstacleProduct {
private:
    std::string name;
public:
    explicit CityObstacle(const std::string& n) : name(n) {}
    void print() const override;
};

#endif