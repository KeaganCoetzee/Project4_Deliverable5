#include "Decorator.h"
#include <iostream>

// Base Decorator Implementation
Decorator::Decorator(std::string n, MapComponent* w) : name(n), wrappee(w) {}
Decorator::Decorator(MapComponent* w, std::string n) : name(n), wrappee(w) {}

Decorator::~Decorator() {
    delete wrappee;
}

void Decorator::print() const {
    if (wrappee) wrappee->print();
}

// WeatherDecorator
WeatherDecorator::WeatherDecorator(std::string n, MapComponent* w) : Decorator(n, w) {}
WeatherDecorator::WeatherDecorator(MapComponent* w, std::string n) : Decorator(w, n) {}

void WeatherDecorator::print() const {
    Decorator::print();
    std::cout << "  -> [Weather Event: " << name << "]" << std::endl;
}

// TollDecorator
TollDecorator::TollDecorator(std::string n, MapComponent* w) : Decorator(n, w) {}
TollDecorator::TollDecorator(MapComponent* w, std::string n) : Decorator(w, n) {}
TollDecorator::TollDecorator(MapComponent* w, double fee) 
    : Decorator(w, ""), amount(fee), isNumericFee(true) {}

void TollDecorator::print() const {
    Decorator::print();
    if (isNumericFee) {
        std::cout << "  -> [Toll Gate: Fee $" << amount << "]" << std::endl;
    } else {
        std::cout << "  -> [Toll Gate: " << name << "]" << std::endl;
    }
}

// QuestDecorator
QuestDecorator::QuestDecorator(std::string n, MapComponent* w) : Decorator(n, w) {}
QuestDecorator::QuestDecorator(MapComponent* w, std::string n) : Decorator(w, n) {}
QuestDecorator::QuestDecorator(MapComponent* w, std::string title, std::string desc)
    : Decorator(w, title), description(desc) {}

void QuestDecorator::print() const {
    Decorator::print();
    if (!description.empty()) {
        std::cout << "  -> [Active Quest: " << name << " - " << description << "]" << std::endl;
    } else {
        std::cout << "  -> [Active Quest: " << name << "]" << std::endl;
    }
}

// TimeOfDayDecorator
TimeOfDayDecorator::TimeOfDayDecorator(std::string n, MapComponent* w) : Decorator(n, w) {}
TimeOfDayDecorator::TimeOfDayDecorator(MapComponent* w, std::string n) : Decorator(w, n) {}

void TimeOfDayDecorator::print() const {
    Decorator::print();
    std::cout << "  -> [Time of Day: " << name << "]" << std::endl;
}