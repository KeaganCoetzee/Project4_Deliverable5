#ifndef MAPCOMPONENT_H
#define MAPCOMPONENT_H

#include <string>
#include <vector>

// ---------- Abstract Component ----------
class MapComponent {
    public:
        virtual void print() const = 0;
        virtual ~MapComponent() {}
};

// ---------- Leaf ----------
class Location : public MapComponent {
    private:
        std::string name;

    public:
        Location(const std::string& n) : name(n) {}
        void print() const override;
        ~Location() override {}
};

// ---------- Composite ----------
class Region : public MapComponent {
    private:
        std::string name;
        std::vector<MapComponent*> children;

    public:
        Region(const std::string& n) : name(n) {}
        ~Region() override;

        void add(MapComponent* component);
        void remove(MapComponent* component);
        void replace(MapComponent* oldComponent, MapComponent* newComponent);
        void print() const override;
};

#endif