#include "WorldBuilder.h"
#include "WorldProduct.h"

// ---------- DesertFactory ----------
NPCProduct* DesertFactory::createNPC() {
    return new DesertNPC("Nomad Trader");
}
TerrainProduct* DesertFactory::createTerrain() {
    return new DesertTerrain("Rolling Dunes");
}
ObstacleProduct* DesertFactory::createObstacle() {
    return new DesertObstacle("Sudden Sandstorm");
}

// ---------- OceanFactory ----------
NPCProduct* OceanFactory::createNPC() {
    return new OceanNPC("Wandering Fisher");
}
TerrainProduct* OceanFactory::createTerrain() {
    return new OceanTerrain("Open Reef");
}
ObstacleProduct* OceanFactory::createObstacle() {
    return new OceanObstacle("Riptide Current");
}

// ---------- ForestFactory ----------
NPCProduct* ForestFactory::createNPC() {
    return new ForestNPC("Reclusive Hermit");
}
TerrainProduct* ForestFactory::createTerrain() {
    return new ForestTerrain("Dense Canopy");
}
ObstacleProduct* ForestFactory::createObstacle() {
    return new ForestObstacle("Fallen Deadwood");
}

// ---------- SnowFactory ----------
NPCProduct* SnowFactory::createNPC() {
    return new SnowNPC("Frostbound Scout");
}
TerrainProduct* SnowFactory::createTerrain() {
    return new SnowTerrain("Frozen Ridge");
}
ObstacleProduct* SnowFactory::createObstacle() {
    return new SnowObstacle("Avalanche Risk");
}

// ---------- CityFactory ----------
NPCProduct* CityFactory::createNPC() {
    return new CityNPC("Street Vendor");
}
TerrainProduct* CityFactory::createTerrain() {
    return new CityTerrain("Cobbled Alley");
}
ObstacleProduct* CityFactory::createObstacle() {
    return new CityObstacle("Blocked Checkpoint");
}