#include "Traveller.h"
#include <iostream>

Traveller::Traveller(MoveState* initState) : currentState(initState), currentLocation(nullptr) {}

Traveller::~Traveller() {
    delete currentState; 
}

void Traveller::move() {
    if (currentState) currentState->move(this);
}

bool Traveller::changeState(MoveState* newState) {
    if (currentState->canTransitionTo(newState, currentLocation)) {
        delete currentState; 
        currentState = newState;
        return true;
    }
    std::cout << "Cannot transition to " << newState->getName() << " here." << std::endl;
    delete newState; 
    return false;
}

std::string Traveller::getCurrentModeName() {
    return currentState ? currentState->getName() : "None";
}

Location* Traveller::getCurrentLocation() { return currentLocation; }
void Traveller::setCurrentLocation(Location* loc) { currentLocation = loc; }