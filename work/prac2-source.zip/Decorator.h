#ifndef DECORATOR_H
#define DECORATOR_H

#include "MapComponent.h"
#include <string>

// Base Decorator
class Decorator : public MapComponent {
protected:
    std::string name;
    MapComponent* wrappee;

public:
    Decorator(std::string n, MapComponent* w);
    Decorator(MapComponent* w, std::string n = "");
    virtual ~Decorator();
    void print() const override;
};

// WeatherDecorator
class WeatherDecorator : public Decorator {
public:
    WeatherDecorator(std::string n, MapComponent* w);
    WeatherDecorator(MapComponent* w, std::string n);
    void print() const override;
};

// TollDecorator
class TollDecorator : public Decorator {
private:
    double amount = 0.0;
    bool isNumericFee = false;
public:
    TollDecorator(std::string n, MapComponent* w);
    TollDecorator(MapComponent* w, std::string n);
    TollDecorator(MapComponent* w, double fee);
    void print() const override;
};

// QuestDecorator
class QuestDecorator : public Decorator {
private:
    std::string description;
public:
    QuestDecorator(std::string n, MapComponent* w);
    QuestDecorator(MapComponent* w, std::string n);
    QuestDecorator(MapComponent* w, std::string title, std::string desc);
    void print() const override;
};

// TimeOfDayDecorator
class TimeOfDayDecorator : public Decorator {
public:
    TimeOfDayDecorator(std::string n, MapComponent* w);
    TimeOfDayDecorator(MapComponent* w, std::string n);
    void print() const override;
};

#endif