#include "GameManager.h"
#include <iostream>
#include <limits>

GameManager::GameManager() {
    mode = 1;
    routeType = "Scenic";
    player = nullptr;
    trip = nullptr;
    worldMap = nullptr;
    currentBiomeFactory = nullptr;
    activeLocation = nullptr;
}

GameManager::~GameManager() {
    delete player;
    delete trip;
    delete worldMap;
    delete currentBiomeFactory;
}

void GameManager::build() {
    delete player;
    delete trip;
    delete worldMap;

    player = new Traveller(new WalkingState());
    trip = new Trip(new ScenicRouteStrategy());
    
    worldMap = new Region("Global Map");
    
    Region* north = new Region("North Pole");
    north->add(new Location("Alpine Pass"));
    north->add(new Location("Summit Station"));
    
    Region* east = new Region("Eastern Seaboard");
    Location* harbor = new Location("Coastal Harbor");
    east->add(new Location("Reef Outpost"));
    east->add(harbor);
    
    Region* south = new Region("Desert Dunes");
    south->add(new Location("Dune Ridge"));
    south->add(new Location("Dry Basin"));
    
    worldMap->add(north);
    worldMap->add(east);
    worldMap->add(south);
    
    activeLocation = harbor;
    player->setCurrentLocation(activeLocation);
    
    std::cout << "[System] Map loaded." << std::endl;
}

void GameManager::move() {
    if (!player) return;

    std::cout << "\n--- Select Transport ---" << std::endl;
    std::cout << "1. Walk\n2. Bicycle\n3. Car\n4. Boat\n5. Air\nChoice: ";
    int choice;
    if (!(std::cin >> choice)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }
    
    MoveState* newState = nullptr;
    switch(choice) {
        case 1: newState = new WalkingState(); break;
        case 2: newState = new BicycleState(); break;
        case 3: newState = new CarState(); break;
        case 4: newState = new BoatState(); break;
        case 5: newState = new AirState(); break;
        default: std::cout << "Invalid transport mode." << std::endl; return;
    }
    
    if (player->changeState(newState)) {
        std::cout << "[Update] Transport set to: " << player->getCurrentModeName() << std::endl;
    }
}

void GameManager::plan() {
    if (!trip) return;

    std::cout << "\n--- Select Route Strategy ---" << std::endl;
    std::cout << "1. Fastest\n2. Scenic\n3. Cheapest\n4. Shortest\nChoice: ";
    int choice;
    if (!(std::cin >> choice)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }
    
    switch(choice) {
        case 1: trip->setStrategy(new FastestRouteStrategy()); break;
        case 2: trip->setStrategy(new ScenicRouteStrategy()); break;
        case 3: trip->setStrategy(new CheapestRouteStrategy()); break;
        case 4: trip->setStrategy(new ShortestRouteStrategy()); break;
        default: std::cout << "Invalid strategy." << std::endl; return;
    }
    std::cout << "[Update] Navigation set to " << trip->getCurrentStratName() << "." << std::endl;
}

void* GameManager::makeThing(std::string biome, std::string kind) {
    delete currentBiomeFactory;
    currentBiomeFactory = nullptr;
    
    if (biome == "Forest" || biome == "forest") currentBiomeFactory = new ForestFactory();
    else if (biome == "Desert" || biome == "desert") currentBiomeFactory = new DesertFactory();
    else if (biome == "Ocean" || biome == "ocean") currentBiomeFactory = new OceanFactory();
    else if (biome == "Snow" || biome == "snow") currentBiomeFactory = new SnowFactory();
    else if (biome == "City" || biome == "city") currentBiomeFactory = new CityFactory();
    else return nullptr;
    
    if (kind == "Terrain") {
        TerrainProduct* t = currentBiomeFactory->createTerrain();
        if (t) { t->print(); delete t; }
    } else if (kind == "NPC") {
        NPCProduct* n = currentBiomeFactory->createNPC();
        if (n) { n->print(); delete n; }
    } else if (kind == "Obstacle") {
        ObstacleProduct* o = currentBiomeFactory->createObstacle();
        if (o) { o->print(); delete o; }
    }
    return nullptr;
}

void GameManager::setBiome(WorldBuilder* builder) {
    delete currentBiomeFactory;
    currentBiomeFactory = builder;
}

void GameManager::enterBiome() {
    if (!currentBiomeFactory) {
        std::cout << "[Warning] No active biome set." << std::endl;
        return;
    }

    TerrainProduct* terrain = currentBiomeFactory->createTerrain();
    NPCProduct* npc = currentBiomeFactory->createNPC();
    ObstacleProduct* obstacle = currentBiomeFactory->createObstacle();

    if (terrain) { terrain->print(); delete terrain; }
    if (npc) { npc->print(); delete npc; }
    if (obstacle) { obstacle->print(); delete obstacle; }
}

void GameManager::run() {
    if (!player || !trip || !worldMap) {
        build();
    }
    
    bool playing = true;
    while (playing) {
        std::cout << "\n======================================" << std::endl;
        std::cout << "          WAYFARER EXPLORER           " << std::endl;
        std::cout << "======================================" << std::endl;
        std::cout << "Transport: " << player->getCurrentModeName() 
                  << " | Route: " << trip->getCurrentStratName() << std::endl;
        std::cout << "--------------------------------------" << std::endl;
        std::cout << "1. Change Transport" << std::endl;
        std::cout << "2. Change Routing Strategy" << std::endl;
        std::cout << "3. View World Map" << std::endl;
        std::cout << "4. Travel to Biome" << std::endl;
        std::cout << "5. Quit Game" << std::endl;
        std::cout << "======================================" << std::endl;
        std::cout << "Select an action: ";
        
        int choice;
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            break;
        }

        switch (choice) {
            case 1: 
                move(); 
                break;
            case 2: 
                plan(); 
                break;
            case 3:
                std::cout << "\n--- World Map ---" << std::endl;
                worldMap->print();
                
                std::cout << "\nPress Enter to return to menu...";
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cin.get();
                break;
            case 4: {
                std::cout << "\nEnter Destination Biome (Forest/Desert/Ocean/Snow/City): ";
                std::string biomeChoice;
                std::cin >> biomeChoice;
                
                std::cout << "\n--- Travel Log ---" << std::endl;
                trip->plan();
                player->move();
                
                std::cout << "\n--- Arriving at: " << biomeChoice << " ---" << std::endl;
                makeThing(biomeChoice, "Terrain");
                makeThing(biomeChoice, "NPC");
                makeThing(biomeChoice, "Obstacle");
                
                std::cout << "\nPress Enter to return to menu...";
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cin.get();
                break;
            }
            case 5:
                std::cout << "Exiting system." << std::endl;
                playing = false;
                break;
            default:
                std::cout << "Invalid input." << std::endl;
                break;
        }
    }
}