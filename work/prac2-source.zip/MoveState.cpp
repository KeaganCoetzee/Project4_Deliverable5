#include "MoveState.h"
#include "Traveller.h" 

// Walking State
WalkingState::WalkingState() {} // Constructor implementation
void WalkingState::move(Traveller* traveller) { std::cout << "Walking steadily along the path." << std::endl; }
bool WalkingState::canTransitionTo(MoveState* next, Location* currentLocation) { return true; }

// Bicycle State
BicycleState::BicycleState() {}
void BicycleState::move(Traveller* traveller) { std::cout << "Pedaling the bicycle forward." << std::endl; }
bool BicycleState::canTransitionTo(MoveState* next, Location* currentLocation) {
    if (next->getName() == "Walking") return true;
    return false;
}

// Car State
CarState::CarState() {}
void CarState::move(Traveller* traveller) { std::cout << "Cruising down the road in a 4x4." << std::endl; }
bool CarState::canTransitionTo(MoveState* next, Location* currentLocation) {
    if (next->getName() == "Walking") return true;
    return false;
}

// Boat State
BoatState::BoatState() {}
void BoatState::move(Traveller* traveller) { std::cout << "Navigating across the water." << std::endl; }
bool BoatState::canTransitionTo(MoveState* next, Location* currentLocation) {
    if (next->getName() == "Walking") return true;
    return false;
}

// Air State
AirState::AirState() {}
void AirState::move(Traveller* traveller) { std::cout << "Flying high above the map." << std::endl; }
bool AirState::canTransitionTo(MoveState* next, Location* currentLocation) {
    if (next->getName() == "Walking") return true;
    return false;
}