#include "Trip.h"

Trip::Trip(RouteStrategy* initStrat) : currentStrategy(initStrat) {}

Trip::~Trip() { delete currentStrategy; }

void Trip::plan() {
    if (currentStrategy) currentStrategy->plan(this);
}

void Trip::setStrategy(RouteStrategy* newStrat) {
    delete currentStrategy; 
    currentStrategy = newStrat;
}

std::string Trip::getCurrentStratName() {
    return currentStrategy ? currentStrategy->getName() : "None";
}