#ifndef TRIP_H
#define TRIP_H

#include <string>
#include "RouteStrategy.h"

class RouteStrategy;

class Trip {
private:
    RouteStrategy* currentStrategy;

public:
    Trip(RouteStrategy* initStrat);
    virtual ~Trip();
    
    void plan();
    void setStrategy(RouteStrategy* newStrat);
    std::string getCurrentStratName();
};

#endif