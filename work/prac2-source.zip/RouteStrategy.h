#ifndef ROUTESTRATEGY_H
#define ROUTESTRATEGY_H

#include <iostream>
#include <string>

class Trip;

class RouteStrategy {
public:
    virtual ~RouteStrategy() = default;
    virtual void plan(Trip* trip) = 0;
    virtual std::string getName() = 0;
};

class FastestRouteStrategy : public RouteStrategy {
public:
    void plan(Trip* trip) override;
    std::string getName() override { return "Fastest"; }
};

class CheapestRouteStrategy : public RouteStrategy {
public:
    void plan(Trip* trip) override;
    std::string getName() override { return "Cheapest"; }
};

class ScenicRouteStrategy : public RouteStrategy {
public:
    void plan(Trip* trip) override;
    std::string getName() override { return "Scenic"; }
};

class ShortestRouteStrategy : public RouteStrategy {
public:
    void plan(Trip* trip) override;
    std::string getName() override { return "Shortest"; }
};

#endif