#include "MapComponent.h"
#include <iostream>

using namespace std;

// ---------- Location ----------
void Location::print() const {
    cout << name;
}

// ---------- Region ----------
Region::~Region() {
    for (MapComponent* child : children) {
        delete child;
    }
    children.clear();
}

void Region::add(MapComponent* component) {
    if (component) {
        children.push_back(component);
    }
}

void Region::remove(MapComponent* component) {
    for (auto it = children.begin(); it != children.end(); ++it) {
        if (*it == component) {
            delete *it;
            children.erase(it);
            return;
        }
    }
}

void Region::replace(MapComponent* oldComponent, MapComponent* newComponent) {
    for (size_t i = 0; i < children.size(); ++i) {
        if (children[i] == oldComponent) {
            children[i] = newComponent;
            return;
        }
    }
}

void Region::print() const {
    cout << name << ": [";
    for (size_t i = 0; i < children.size(); ++i) {
        children[i]->print();
        if (i + 1 < children.size()) {
            cout << ", ";
        }
    }
    cout << "]";
}