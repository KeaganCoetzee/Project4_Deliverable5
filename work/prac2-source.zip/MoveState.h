#ifndef MOVESTATE_H
#define MOVESTATE_H

#include <iostream>
#include <string>

class Location; 
class Traveller;

class MoveState {
public:
    virtual ~MoveState() = default; 
    virtual void move(Traveller* traveller) = 0;
    virtual bool canTransitionTo(MoveState* next, Location* currentLocation) = 0;
    virtual std::string getName() = 0;
};

class WalkingState : public MoveState {
public:
    WalkingState();
    void move(Traveller* traveller) override;
    bool canTransitionTo(MoveState* next, Location* currentLocation) override;
    std::string getName() override { return "Walking"; }
};

class BicycleState : public MoveState {
public:
    BicycleState();
    void move(Traveller* traveller) override;
    bool canTransitionTo(MoveState* next, Location* currentLocation) override;
    std::string getName() override { return "Bicycle"; }
};

class CarState : public MoveState {
public:
    CarState();
    void move(Traveller* traveller) override;
    bool canTransitionTo(MoveState* next, Location* currentLocation) override;
    std::string getName() override { return "Car"; }
};

class BoatState : public MoveState {
public:
    BoatState();
    void move(Traveller* traveller) override;
    bool canTransitionTo(MoveState* next, Location* currentLocation) override;
    std::string getName() override { return "Boat"; }
};

class AirState : public MoveState {
public:
    AirState();
    void move(Traveller* traveller) override;
    bool canTransitionTo(MoveState* next, Location* currentLocation) override;
    std::string getName() override { return "Air"; }
};

#endif