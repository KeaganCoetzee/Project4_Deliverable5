#include "RouteStrategy.h"
#include "Trip.h"

void FastestRouteStrategy::plan(Trip* trip) { 
    std::cout << "Plotting the fastest route via major highways." << std::endl; 
}

void CheapestRouteStrategy::plan(Trip* trip) { 
    std::cout << "Plotting the cheapest route, avoiding all toll gates." << std::endl; 
}

void ScenicRouteStrategy::plan(Trip* trip) { 
    std::cout << "Plotting a scenic route through mountain passes and reserves." << std::endl; 
}

void ShortestRouteStrategy::plan(Trip* trip) { 
    std::cout << "Plotting the absolute shortest route by total distance." << std::endl; 
}