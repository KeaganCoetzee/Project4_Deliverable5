#include "GameManager.h"
#include "MoveState.h"
#include "RouteStrategy.h"
#include "WorldBuilder.h"
#include "WorldProduct.h"
#include "MapComponent.h"
#include "Decorator.h"
#include "Traveller.h"
#include "Trip.h"
#include <iostream>
#include <sstream>
#include <vector>
#include <string>

// ==========================================
// 1. FULL COVERAGE TEST SUITE
// ==========================================
void runFullCoverageTests() {
    std::cout << "==========================================" << std::endl;
    std::cout << "  RUNNING FULL COVERAGE TEST" << std::endl;
    std::cout << "==========================================" << std::endl;

    // ----------------------------------------------------
    // [1] MoveStates & Traveller
    // ----------------------------------------------------
    std::cout << "\n--- 1. Testing MoveStates & Traveller ---" << std::endl;
    Traveller* traveller = new Traveller(new WalkingState());
    Location* hub = new Location("Central Hub");
    traveller->setCurrentLocation(hub);
    (void)traveller->getCurrentLocation();
    (void)traveller->getCurrentModeName();

    traveller->move();

    // Bicycle transitions (valid & invalid)
    traveller->changeState(new BicycleState());
    (void)traveller->getCurrentModeName();
    traveller->move();
    traveller->changeState(new CarState());     // Rejection branch
    traveller->changeState(new WalkingState()); // Return to walk

    // Car transitions (valid & invalid)
    traveller->changeState(new CarState());
    (void)traveller->getCurrentModeName();
    traveller->move();
    traveller->changeState(new BoatState());    // Rejection branch
    traveller->changeState(new WalkingState());

    // Boat transitions (valid & invalid)
    traveller->changeState(new BoatState());
    (void)traveller->getCurrentModeName();
    traveller->move();
    traveller->changeState(new AirState());     // Rejection branch
    traveller->changeState(new WalkingState());

    // Air transitions (valid & invalid)
    traveller->changeState(new AirState());
    (void)traveller->getCurrentModeName();
    traveller->move();
    traveller->changeState(new BicycleState()); // Rejection branch
    traveller->changeState(new WalkingState());

    delete traveller;
    delete hub;

    // ----------------------------------------------------
    // [2] Route Strategies & RouteStrategy.h (.getName())
    // ----------------------------------------------------
    std::cout << "\n--- 2. Testing Route Strategies ---" << std::endl;
    RouteStrategy* stratFast = new FastestRouteStrategy();
    RouteStrategy* stratScenic = new ScenicRouteStrategy();
    RouteStrategy* stratCheap = new CheapestRouteStrategy();
    RouteStrategy* stratShort = new ShortestRouteStrategy();

    // Call .getName() directly on all strategies to achieve 100% on RouteStrategy.h
    std::cout << "Strategies: " << stratFast->getName() << ", " 
              << stratScenic->getName() << ", " 
              << stratCheap->getName() << ", " 
              << stratShort->getName() << std::endl;

    Trip* trip = new Trip(stratFast);
    (void)trip->getCurrentStratName();
    trip->plan();

    trip->setStrategy(stratScenic);
    (void)trip->getCurrentStratName();
    trip->plan();

    trip->setStrategy(stratCheap);
    (void)trip->getCurrentStratName();
    trip->plan();

    trip->setStrategy(stratShort);
    (void)trip->getCurrentStratName();
    trip->plan();

    delete trip;

    // ----------------------------------------------------
    // [3] Abstract Factories & Products
    // ----------------------------------------------------
    std::cout << "\n--- 3. Testing Factories & Products ---" << std::endl;
    std::vector<WorldBuilder*> factories = {
        new DesertFactory(),
        new OceanFactory(),
        new ForestFactory(),
        new SnowFactory(),
        new CityFactory()
    };

    for (WorldBuilder* factory : factories) {
        NPCProduct* npc = factory->createNPC();
        TerrainProduct* terrain = factory->createTerrain();
        ObstacleProduct* obstacle = factory->createObstacle();

        if (npc) { npc->print(); delete npc; }
        if (terrain) { terrain->print(); delete terrain; }
        if (obstacle) { obstacle->print(); delete obstacle; }

        delete factory;
    }

    // ----------------------------------------------------
    // [4] MapComponent & All Decorators
    // ----------------------------------------------------
    std::cout << "\n--- 4. Testing MapComponent & Decorators ---" << std::endl;
    
    // Standalone Location & Empty Region
    Location* standaloneLoc = new Location("Solo Location");
    standaloneLoc->print();
    delete standaloneLoc;

    Region* emptyReg = new Region("Empty Region");
    emptyReg->print();
    delete emptyReg;

    // Composite tree
    Region* world = new Region("Aethelgard World");
    Region* subRegion = new Region("Sub Region");
    Location* p1 = new Location("Point Alpha");
    Location* p2 = new Location("Point Beta");

    subRegion->add(p1);
    subRegion->add(p2);
    world->add(subRegion);
    world->print();
    delete world;

    // Exercise each Decorator type individually to cover all subclasses in Decorator.cpp
    MapComponent* d1 = new WeatherDecorator("Blizzard", new Location("L1"));
    d1->print();
    delete d1;

    MapComponent* d2 = new TollDecorator("Gate A", new Location("L2"));
    d2->print();
    delete d2;

    MapComponent* d3 = new QuestDecorator("Find Relic", new Location("L3"));
    d3->print();
    delete d3;

    MapComponent* d4 = new TimeOfDayDecorator("Dusk", new Location("L4"));
    d4->print();
    delete d4;

    // Nested Decorator
    MapComponent* deepDecorated = new WeatherDecorator(
        "Heavy Rain",
        new TollDecorator(
            "Toll Bridge",
            new QuestDecorator(
                "Escort Quest",
                new TimeOfDayDecorator(
                    "Midnight",
                    new Location("Deep Fortress")
                )
            )
        )
    );
    deepDecorated->print();
    delete deepDecorated;

    // ----------------------------------------------------
    // [5] GameManager 100% Code Coverage
    // ----------------------------------------------------
    std::cout << "\n--- 5. Testing GameManager Methods ---" << std::endl;
    GameManager game;
    game.build();

    // Biome injection methods
    game.setBiome(new ForestFactory());
    game.enterBiome();
    game.setBiome(new DesertFactory());
    game.enterBiome();
    game.setBiome(new OceanFactory());
    game.enterBiome();
    game.setBiome(new SnowFactory());
    game.enterBiome();
    game.setBiome(new CityFactory());
    game.enterBiome();

    // makeThing() coverage across all types and biomes
    game.makeThing("Forest", "Terrain");
    game.makeThing("Forest", "NPC");
    game.makeThing("Forest", "Obstacle");
    game.makeThing("Desert", "Terrain");
    game.makeThing("Desert", "NPC");
    game.makeThing("Desert", "Obstacle");
    game.makeThing("Ocean", "Terrain");
    game.makeThing("Ocean", "NPC");
    game.makeThing("Ocean", "Obstacle");
    game.makeThing("Snow", "Terrain");
    game.makeThing("Snow", "NPC");
    game.makeThing("Snow", "Obstacle");
    game.makeThing("City", "Terrain");
    game.makeThing("City", "NPC");
    game.makeThing("City", "Obstacle");
    game.makeThing("InvalidBiome", "Terrain");
    game.makeThing("City", "InvalidKind");

    // Simulate cin inputs to execute move(), plan(), and run() without user blocking
    std::streambuf* origCin = std::cin.rdbuf();

    // Test move() all branches: 1, 2, 3, 4, 5, invalid (99)
    std::istringstream moveStream("1\n2\n3\n4\n5\n99\n");
    std::cin.rdbuf(moveStream.rdbuf());
    game.move();
    game.move();
    game.move();
    game.move();
    game.move();
    game.move();

    // Test plan() all branches: 1, 2, 3, 4, invalid (99)
    std::istringstream planStream("1\n2\n3\n4\n99\n");
    std::cin.rdbuf(planStream.rdbuf());
    game.plan();
    game.plan();
    game.plan();
    game.plan();
    game.plan();

    // Test run() loop via simulated input sequence:
    // 1 (move -> 1) -> 2 (plan -> 2) -> 3 (view map) -> 4 (travel -> Forest) -> 5 (quit)
    std::istringstream runStream("1\n1\n2\n2\n3\n\n4\nForest\n\n5\n");
    std::cin.rdbuf(runStream.rdbuf());
    game.run();

    // Restore standard cin
    std::cin.rdbuf(origCin);

    std::cout << "\n==========================================" << std::endl;
    std::cout << "    ALL UNIT TESTS EXECUTED      " << std::endl;
    std::cout << "==========================================" << std::endl;
}

// ==========================================
// MAIN ENTRY POINT
// ==========================================
int main(int argc, char* argv[]) {
    if (argc > 1 && (std::string(argv[1]) == "play" || std::string(argv[1]) == "-i")) {
        GameManager game;
        game.run();
        return 0;
    }

    runFullCoverageTests();
    return 0;
}