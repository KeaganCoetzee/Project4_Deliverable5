#ifndef WORLDBUILDER_H
#define WORLDBUILDER_H

class NPCProduct;
class TerrainProduct;
class ObstacleProduct;
#include "WorldProduct.h"

// ---------- Abstract Factory ----------
class WorldBuilder {
public:
    virtual NPCProduct* createNPC() = 0;
    virtual TerrainProduct* createTerrain() = 0;
    virtual ObstacleProduct* createObstacle() = 0;
    virtual ~WorldBuilder() = default;
};

// ---------- Concrete Factories ----------

class DesertFactory : public WorldBuilder {
public:
    NPCProduct* createNPC() override;
    TerrainProduct* createTerrain() override;
    ObstacleProduct* createObstacle() override;
};

class OceanFactory : public WorldBuilder {
public:
    NPCProduct* createNPC() override;
    TerrainProduct* createTerrain() override;
    ObstacleProduct* createObstacle() override;
};

class ForestFactory : public WorldBuilder {
public:
    NPCProduct* createNPC() override;
    TerrainProduct* createTerrain() override;
    ObstacleProduct* createObstacle() override;
};

class SnowFactory : public WorldBuilder {
public:
    NPCProduct* createNPC() override;
    TerrainProduct* createTerrain() override;
    ObstacleProduct* createObstacle() override;
};

class CityFactory : public WorldBuilder {
public:
    NPCProduct* createNPC() override;
    TerrainProduct* createTerrain() override;
    ObstacleProduct* createObstacle() override;
};

#endif