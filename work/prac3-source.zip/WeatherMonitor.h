#ifndef WEATHERMONITOR_H
#define WEATHERMONITOR_H

#include "Subject.h"

/**
 * @class WeatherMonitor
 * @brief Concrete Subject tracking real-time meteorological conditions for the festival.
 */
class WeatherMonitor : public Subject {
private:
    /** Current ambient temperature in degrees Celsius. */
    float temperature;
    /** Probability of precipitation as a percentage */
    int rainProbability;

public:
    /**
     * @brief Default constructor initializing default weather values.
     */
    WeatherMonitor();

    /**
     * @brief Virtual destructor.
     */
    virtual ~WeatherMonitor() = default;

    /**
     * @brief Sets the current temperature and notifies observers.
     * @param temp The new temperature in degrees Celsius.
     */
    void setTemperature(float temp);

    /**
     * @brief Retrieves the current temperature.
     * @return Ambient temperature as a float.
     */
    float getTemperature() const;

    /**
     * @brief Sets the rain probability percentage and notifies observers.
     * @param chances The new rain probability percentage.
     */
    void setRainProbability(int chances);

    /**
     * @brief Retrieves the current rain probability.
     * @return Rain probability as an integer percentage.
     */
    int getRainProbability() const;
};

#endif