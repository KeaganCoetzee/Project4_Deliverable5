#include "FestivalGate.h"
#include "WeatherMonitor.h"
#include <iostream>

FestivalGate::FestivalGate(std::string name, int capacity, Status status, WeatherMonitor* monitor)
    : EventUnit(name, capacity, status, monitor) {}

void FestivalGate::open() { 
    status = Status::OPEN; 
}

void FestivalGate::close() { 
    status = Status::CLOSED; 
}

int FestivalGate::getCapacity() const { 
    return capacity; 
}

void FestivalGate::reportStatus() const {
    std::cout << "Festival Gate: " << name << " | Capacity: " << capacity << std::endl;
}

void FestivalGate::update() {
    std::cout << "[INFO] Gate " << name << " received an update." << std::endl;
}

void FestivalGate::triggerEvacuation() {
    status = Status::OPEN;
    capacity = 9999; // turnstiles open for everyone
    std::cout << "[EMERGENCY] " << name << " turnstiles opened fully. Capacity set to infinite for escape." << std::endl;
}