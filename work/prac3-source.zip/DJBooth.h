#ifndef DJBOOTH_H
#define DJBOOTH_H

#include <string>
#include "EventUnit.h"

class PowerGrid;

/**
 * @class DJBooth
 * @brief Concrete leaf unit representing a DJ performance area responsive to power and weather.
 */
class DJBooth : public EventUnit {
private:
    /** Pointer to the local power grid subject. */
    PowerGrid* localGrid;

public:

    /**
     * @brief Constructs a DJBooth instance.
     * @param name Name of the DJ booth.
     * @param capacity Maximum capacity.
     * @param status Initial operational status.
     * @param monitor Pointer to the associated WeatherMonitor.
     */
    DJBooth(std::string name, int capacity, Status status, WeatherMonitor* monitor);

    /**
     * @brief Virtual destructor.
     */
    virtual ~DJBooth() = default;

    void open() override;
    void close() override;
    void reportStatus() const override;
    int getCapacity() const override;

    void update() override;
    void triggerEvacuation() override;

    /**
     * @brief Links the DJ booth to an external PowerGrid subject.
     * @param grid Pointer to the PowerGrid.
     */
    void setPowerGrid(PowerGrid* grid);
};

#endif