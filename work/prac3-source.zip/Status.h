#ifndef STATUS_H
#define STATUS_H

/**
 * @brief Represents the operational state of an event component.
 */
enum class Status {
    CLOSED,
    OPEN,
    PAUSED,
    SUSPENDED
};

#endif