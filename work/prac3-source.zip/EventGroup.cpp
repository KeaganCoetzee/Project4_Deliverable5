#include "EventGroup.h"
#include <iostream>
#include <algorithm>

EventGroup::EventGroup(std::string name) : name(name) {}

EventGroup::~EventGroup() {
    for (auto child : children) {
        delete child; 
    }
    children.clear();
}

void EventGroup::open() {
    for (auto child : children) {
        child->open();
    }
}

void EventGroup::close() {
    for (auto child : children) {
        child->close();
    }
}

void EventGroup::reportStatus() const {
    std::cout << "--- Group: " << name << " ---" << std::endl;
    for (auto child : children) {
        child->reportStatus();
    }
}

int EventGroup::getCapacity() const {
    int total = 0;
    for (auto child : children) {
        total += child->getCapacity();
    }
    return total;
}



// orginal design
void EventGroup::triggerEvacuation() {
    std::cout << "[ALERT] Evacuating zone: " << name << std::endl;
    for (EventComponent* child : children) {
        if (child != nullptr) {
            child->triggerEvacuation();
        }
    }
}

void EventGroup::add(EventComponent* zone) {
    children.push_back(zone);
}

void EventGroup::remove(EventComponent* zone) {
    children.erase(std::remove(children.begin(), children.end(), zone), children.end());
}

void EventGroup::update() {
    for (EventComponent* child : children) {
        if (child != nullptr) {
            child->update();
        }
    }
}

void EventGroup::balanceCrowds() {
    if (getCapacity() > 10) { 
        std::cout << "[PROMO] " << name << " is heavily congested!." << std::endl;
    } else {
        std::cout << "[INFO] " << name << " capacity is optimal." << std::endl;
    }
}