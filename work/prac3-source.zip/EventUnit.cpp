#include "EventUnit.h"

EventUnit::EventUnit(std::string name, int capacity, Status status, WeatherMonitor* monitor) : name(name), capacity(capacity), status(status), weatherMonitor(monitor) {}