#ifndef PERFORMANCESTAGE_H
#define PERFORMANCESTAGE_H

#include "EventUnit.h"
#include <string>

/**
 * @class PerformanceStage
 * @brief Concrete leaf unit representing a live music performance stage
 */
class PerformanceStage : public EventUnit {
private:
    /** The name of the artist currently performing. */
    std::string currentArtist;

public:
    /**
     * @brief Constructs a PerformanceStage instance.
     * @param name Name of the stage.
     * @param artist Name of the current artist.
     * @param capacity Maximum crowd capacity.
     * @param status Initial operational status.
     * @param monitor Pointer to the associated WeatherMonitor.
     */
    PerformanceStage(std::string name, std::string artist, int capacity, Status status, WeatherMonitor* monitor);

    /**
     * @brief Virtual destructor.
     */
    virtual ~PerformanceStage() = default;

    /**
     * @brief Sets or updates the performing artist.
     * @param artist The new artist's name.
     */
    void setArtist(std::string artist);
    void open() override;
    void close() override;
    void reportStatus() const override;
    int getCapacity() const override;
    void update() override;
    void triggerEvacuation() override;
};

#endif