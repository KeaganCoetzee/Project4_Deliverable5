#include <iostream>
#include "WeatherMonitor.h"
#include "EventGroup.h"
#include "PerformanceStage.h"
#include "DJBooth.h"
#include "MedicalTent.h"
#include "FoodVendor.h"
#include "FestivalGate.h"
#include "PowerGrid.h"

int main() {
    std::cout << "=== EVENT FLOW ===" << std::endl;

    // make the Subject
    WeatherMonitor* monitor = new WeatherMonitor();
    monitor->setTemperature(25.7f);
    monitor->setRainProbability(20);

    // build tree structure
    // level 0
    EventGroup* monate = new EventGroup("monate");

    // level 1
    EventGroup* mainStageZone = new EventGroup("mainStageZone");
    EventGroup* festivalServiceZone = new EventGroup("festivalServicesZone");

    // level 2
    EventGroup* mainStageArea = new EventGroup("mainStageArea");
    EventGroup* electronicsArea = new EventGroup("electronicsArea");
    EventGroup* foodZone = new EventGroup("foodZone");
    EventGroup* healthZone = new EventGroup("healthZone");

    // create the structure
    monate->add(mainStageZone);
    monate->add(festivalServiceZone);
    
    mainStageZone->add(mainStageArea);
    mainStageZone->add(electronicsArea);
    
    festivalServiceZone->add(foodZone);
    festivalServiceZone->add(healthZone);

    // create concrete leaves
    PerformanceStage* stage = new PerformanceStage("stage", "J. Cole", 2, Status::OPEN, monitor);
    FestivalGate* gate = new FestivalGate("entrance3", 5, Status::OPEN, monitor);
    DJBooth* booth = new DJBooth("both", 2, Status::OPEN, monitor);
    FoodVendor* vendor1 = new FoodVendor("vendor1", 15, Status::OPEN, monitor);
    FoodVendor* vendor2 = new FoodVendor("vendor2", 20, Status::OPEN, monitor);
    MedicalTent* firstAidStation = new MedicalTent("station1", 40, Status::OPEN, monitor);

    // attach leaves to parent
    mainStageArea->add(stage);
    mainStageArea->add(gate);
    electronicsArea->add(booth);
    foodZone->add(vendor1);
    foodZone->add(vendor2);
    healthZone->add(firstAidStation);

    // register Observers
    // (registering root will allow notification to go down the whole tree)
    // Attach the composite structure Observers to the Subject
    monitor->attach(monate);

    // show the traversal
    std::cout << "\n--- INITIAL STATE ---" << std::endl;
    std::cout << "Total Capacity of 'monate': " << monate->getCapacity() << std::endl;
    monate->reportStatus();

    // triggering the Observer)
    std::cout << "\n--- TRIGGERING WEATHER UPDATE (80% RAIN) ---" << std::endl;
    monitor->setRainProbability(80);

    //runtime hierarchie reorganise
    std::cout << "\n--- RUNTIME REORGANIZATION ---" << std::endl;
    std::cout << "[INFO] Relocating First Aid Station to Main Stage Area..." << std::endl;
    healthZone->remove(firstAidStation);
    mainStageArea->add(firstAidStation);
    
    std::cout << "\n--- POST-REORGANIZATION STATUS ---" << std::endl;
    monate->reportStatus();

    // --- NEW FEATURE SHOWCASE ---
    
    // Feature 3 Showcase
    std::cout << "\n--- CHECKING CAPACITY SPILLOVER ---" << std::endl;
    mainStageZone->balanceCrowds(); 

    // Feature 2 Showcase
    std::cout << "\n--- TRIGGERING POWER FAILURE ---" << std::endl;
    PowerGrid* festivalGrid = new PowerGrid();
    booth->setPowerGrid(festivalGrid);
    festivalGrid->attach(booth);
    festivalGrid->setPowerState(false);

    // Feature 1 Showcase
    std::cout << "\n--- INITIATING EMERGENCY EVACUATION ---" << std::endl;
    monate->triggerEvacuation();

    // Remember to add 'delete festivalGrid;' to your cleanup section!

    // shutdown and cleanup
    std::cout << "\n--- CLEANING UP MEMORY ---" << std::endl;
    delete monate;
    delete monitor;

    return 0;
}