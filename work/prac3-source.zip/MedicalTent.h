#ifndef MEDICALTENT_H
#define MEDICALTENT_H

#include "EventUnit.h"
#include <string>

using namespace std;

/**
 * @class MedicalTent
 * @brief Concrete leaf unit representing a medical or first aid tent
 */
class MedicalTent : public EventUnit{
    public:

        /**
         * @brief Constructs a MedicalTent instance.
         * @param name Name of the medical tent.
         * @param capacity Maximum patient capacity.
         * @param status Initial operational status.
         * @param monitor Pointer to the associated WeatherMonitor.
         */
        MedicalTent(string name, int capacity, Status status, WeatherMonitor* monitor);

        /**
         * @brief Virtual destructor.
         */
        virtual ~MedicalTent() = default;

        void open() override;
        void close() override;
        void reportStatus() const override;
        int getCapacity() const override;
        void update() override;
        void triggerEvacuation() override;
};

#endif