#ifndef FESTIVALGATE_H
#define FESTIVALGATE_H

#include "EventUnit.h"
#include <string>

/**
 * @class FestivalGate
 * @brief Concrete leaf unit representing an entrance gate to the festival
 */
class FestivalGate : public EventUnit {
public:
    /**
     * @brief Constructs a FestivalGate instance.
     * @param name Name of the gate.
     * @param capacity Maximum visitor capacity.
     * @param status Initial operational status.
     * @param monitor Pointer to the associated WeatherMonitor.
     */
    FestivalGate(std::string name, int capacity, Status status, WeatherMonitor* monitor);

    /**
     * @brief Virtual destructor.
     */
    virtual ~FestivalGate() = default;

    void open() override;
    void close() override;
    void reportStatus() const override;
    int getCapacity() const override;
    void update() override;
    void triggerEvacuation() override;
};

#endif