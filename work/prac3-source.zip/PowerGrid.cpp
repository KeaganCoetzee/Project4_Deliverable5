#include "PowerGrid.h"

PowerGrid::PowerGrid() : powerOnline(true) {}

void PowerGrid::setPowerState(bool state) {
    powerOnline = state;
    notify(); 
}

bool PowerGrid::isOnline() const {
    return powerOnline;
}