#include "DJBooth.h"
#include "WeatherMonitor.h"
#include "PowerGrid.h"
#include <iostream>

DJBooth::DJBooth(std::string name, int capacity, Status status, WeatherMonitor* monitor)
    : EventUnit(name, capacity, status, monitor), localGrid(nullptr) {}

void DJBooth::open() {
    status = Status::OPEN;
    std::cout << "[DJBooth] " << name << " is now OPEN." << std::endl;
}

void DJBooth::close() {
    status = Status::CLOSED;
    std::cout << "[DJBooth] " << name << " is now CLOSED." << std::endl;
}

void DJBooth::reportStatus() const {
    std::string statusStr;
    switch (status) {
        case Status::OPEN: statusStr = "OPEN"; break;
        case Status::CLOSED: statusStr = "CLOSED"; break;
        case Status::PAUSED: statusStr = "PAUSED"; break;
        case Status::SUSPENDED: statusStr = "SUSPENDED"; break;
    }
    std::cout << "[DJBooth] Name: " << name << " | Capacity: " << capacity << " | Status: " << statusStr << std::endl;
}

int DJBooth::getCapacity() const {
    return capacity;
}

void DJBooth::update() {
    if (weatherMonitor != nullptr && weatherMonitor->getRainProbability() >= 80) {
        status = Status::PAUSED;
        std::cout << "[WEATHER ALERT] Rain probability is high (" << weatherMonitor->getRainProbability()
                  << "%). DJBooth " << name << " has been PAUSED." << std::endl;
    }

    if (localGrid != nullptr && !localGrid->isOnline()) {
        status = Status::SUSPENDED;
        std::cout << "[POWER FAILURE] DJBooth " << name << " lost power! Set to SUSPENDED." << std::endl;
    }
}

void DJBooth::triggerEvacuation() {
    status = Status::CLOSED;
    std::cout << "[EMERGENCY] " << name << " shutting down turntables and closing." << std::endl;
}

void DJBooth::setPowerGrid(PowerGrid* grid) {
    localGrid = grid;
}