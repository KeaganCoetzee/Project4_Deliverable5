#ifndef EVENTCOMPONENT_H
#define EVENTCOMPONENT_H

#include "Observer.h"
#include "Status.h"

/**
 * @class EventComponent
 * @brief Base Component class in the Composite design pattern, also acting as an Observer.
 */
class EventComponent : public Observer {
public:

    /**
     * @brief Virtual destructor ensuring clean polymorphic teardown.
     */
    virtual ~EventComponent() = default;

    /**
     * @brief Opens the component.
     */
    virtual void open() = 0;
    /**
     * @brief Closes the component.
     */
    virtual void close() = 0;
    /**
     * @brief Prints component status details to standard output.
     */
    virtual void reportStatus() const = 0;
    /**
     * @brief Calculates and returns capacity.
     * @return Total integer capacity.
     */
    virtual int getCapacity() const = 0;
    /**
     * @brief Cascades emergency evacuation procedures down the hierarchy.
     */
    virtual void triggerEvacuation() = 0; //original feature
};

#endif