#ifndef EVENTGROUP_H
#define EVENTGROUP_H

#include "EventComponent.h"
#include <vector>
#include <string>

/**
 * @class EventGroup
 * @brief Composite class holding collections of child EventComponent nodes
 */
class EventGroup : public EventComponent {
private:
/** Identifier name of the group. */
    std::string name;
    /** Child nodes contained within this composite group. */
    std::vector<EventComponent*> children;

public:
    /**
     * @brief Constructs an EventGroup.
     * @param name Name of the group/zone.
     */
    EventGroup(std::string name);

    /**
     * @brief Destructor recursively freeing all dynamically allocated children.
     */
    virtual ~EventGroup(); 


    void open() override;
    void close() override;
    void reportStatus() const override;
    int getCapacity() const override;
    void triggerEvacuation() override;

    /**
     * @brief Adds a child component to this group.
     * @param zone Pointer to the EventComponent child to add.
     */
    void add(EventComponent* zone);
    
    /**
     * @brief Removes a specific child component from this group.
     * @param zone Pointer to the EventComponent child to remove.
     */
    void remove(EventComponent* zone);

    /**
     * @brief Notifies all children components to update their status.
     */
    void update() override;

    /**
     * @brief Evaluates crowd density and initiates crowd dispersion if capacity limits are exceeded.
     */
    void balanceCrowds();
    
};

#endif