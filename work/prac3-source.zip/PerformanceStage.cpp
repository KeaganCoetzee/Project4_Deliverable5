#include "PerformanceStage.h"
#include "WeatherMonitor.h"
#include <iostream>

PerformanceStage::PerformanceStage(std::string name, std::string artist, int capacity, Status status, WeatherMonitor* monitor)
    : EventUnit(name, capacity, status, monitor), currentArtist(artist) {}

void PerformanceStage::setArtist(std::string artist) {
    currentArtist = artist;
}

void PerformanceStage::open() { 
    status = Status::OPEN; 
}

void PerformanceStage::close() { 
    status = Status::CLOSED; 
}

int PerformanceStage::getCapacity() const { 
    return capacity; 
}

void PerformanceStage::reportStatus() const {
    std::cout << "Stage: " << name << " | Artist: " << currentArtist 
              << " | Capacity: " << capacity << std::endl;
}

void PerformanceStage::update() {
    if (weatherMonitor != nullptr) {
        int rain = weatherMonitor->getRainProbability();
        if (rain > 70 && status == Status::OPEN) {
            std::cout << "[ALERT] High rain (" << rain << "%). Pausing " << name << "!" << std::endl;
            status = Status::PAUSED;
        } else if (rain <= 70 && status == Status::PAUSED) {
            std::cout << "[ALERT] Weather clear. Resuming " << name << "!" << std::endl;
            status = Status::OPEN;
        }
    }
}

void PerformanceStage::triggerEvacuation() {
    status = Status::SUSPENDED;
    std::cout << "[EMERGENCY] " << name << " halted immediately. Crowd is being directed to exits." << std::endl;
}