#ifndef EVENTUNIT_H
#define EVENTUNIT_H

#include "EventComponent.h"
#include "Observer.h"
#include "Status.h"
#include <string>

class WeatherMonitor; 

/**
 * @class EventUnit
 * @brief Abstract Leaf base class representing individual, non-composite festival units
 */
class EventUnit : public EventComponent {
protected:
    /** Unit name. */
    std::string name;

    /** Maximum visitor capacity. */
    int capacity;

    /** Current operational state. */
    Status status;

    /** Pointer to the weather subject for observing meteorological changes. */
    WeatherMonitor* weatherMonitor;

public:
    /**
     * @brief Constructs an EventUnit.
     * @param name Unit name.
     * @param capacity Maximum visitor capacity.
     * @param status Initial operational status.
     * @param monitor Weather monitor subject pointer.
     */
    EventUnit(std::string name, int capacity, Status status, WeatherMonitor* monitor);

    /**
     * @brief Virtual destructor.
     */
    virtual ~EventUnit() = default;

};

#endif