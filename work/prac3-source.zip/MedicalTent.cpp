#include "MedicalTent.h"
#include "WeatherMonitor.h"
#include <iostream>

using namespace std;

MedicalTent::MedicalTent(string name, int capacity, Status status, WeatherMonitor* monitor) : EventUnit(name, capacity, status, monitor){}

void MedicalTent::open(){
    status = Status::OPEN;
}

void MedicalTent::close(){
    status = Status::CLOSED;
}

int MedicalTent::getCapacity() const{
    return capacity;
}

void MedicalTent::reportStatus() const {
    cout << "Medical Tent: " << name << " | Capacity: " << capacity << endl;

}

void MedicalTent::update() {
    if (weatherMonitor != nullptr) {
        int rain = weatherMonitor->getRainProbability();
        if (rain > 50) {
            std::cout << "[INFO] Medical Tent " << name << " preparing for rain-related injuries. Status remains OPEN." << std::endl;
        }
    }

}

void MedicalTent::triggerEvacuation() {
    status = Status::CLOSED;
    std::cout << "[EMERGENCY] " << name << " shutting down gas lines and closing." << std::endl;
}