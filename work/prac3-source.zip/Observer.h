#ifndef OBSERVER_H
#define OBSERVER_H

/**
 * @class Observer
 * @brief Abstract interface representing the Observer in the observer design pattern
 * 
 * Defines the update interface for objects that should be notified of changes in a Subject.
 */

class Observer {
public:
    /**
     * @brief Virtual destructor.
     */
    virtual ~Observer() = default;

    /**
     * @brief Pure virtual update method called by subjects when state changes occur.
     */
    virtual void update() = 0;
};

#endif