Google Docs link:
https://docs.google.com/document/d/11QvoVXzgwuDaoX0cIeBhRBKQWBNq6KlYDboSrXzdGQs/edit?usp=sharing