#ifndef SUBJECT_H
#define SUBJECT_H

#include <vector>

class Observer; 


/**
 * @class Subject
 * @brief Abstract Subject base class in Observer design pattern
 * 
 * Maintains a registry of Observer instances and provides functions to attach, detach, and notify observers when internal state changes.
 */
class Subject {
private:
/** List of attached observers. */
    std::vector<Observer*> observers;

public:

    /**
     * @brief Virtual destructor.
     */
    virtual ~Subject() = default;

    /**
     * @brief Registers an observer to receive notifications.
     * @param observer Pointer to the Observer to attach.
     */
    void attach(Observer* observer);

    /**
     * @brief Unregisters an observer from notifications.
     * @param observer Pointer to the Observer to detach.
     */
    void detach(Observer* observer);

    /**
     * @brief Broadcasts an update notification to all attached observers.
     */
    void notify();
};

#endif