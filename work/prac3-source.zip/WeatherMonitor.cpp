#include "WeatherMonitor.h"

WeatherMonitor::WeatherMonitor() : temperature(25.0f), rainProbability(0) {}

void WeatherMonitor::setTemperature(float temp) { 
    temperature = temp; 
    notify(); 
}

float WeatherMonitor::getTemperature() const { 
    return temperature; 
}

void WeatherMonitor::setRainProbability(int chances) { 
    rainProbability = chances; 
    notify(); 
}

int WeatherMonitor::getRainProbability() const { 
    return rainProbability; 
}