#ifndef FOODVENDOR_H
#define FOODVENDOR_H

#include "EventUnit.h"
#include <string>

/**
 * @class FoodVendor
 * @brief Concrete leaf unit representing a food stall at the festival
 */
class FoodVendor : public EventUnit {
public:

    /**
     * @brief Constructs a FoodVendor instance.
     * @param name Name of the food vendor.
     * @param capacity Maximum customer capacity.
     * @param status Initial operational status.
     * @param monitor Pointer to the associated WeatherMonitor.
     */
    FoodVendor(std::string name, int capacity, Status status, WeatherMonitor* monitor);

    /**
     * @brief Virtual destructor.
     */
    virtual ~FoodVendor() = default;

    void open() override;
    void close() override;
    void reportStatus() const override;
    int getCapacity() const override;
    void update() override;
    void triggerEvacuation() override;
};

#endif