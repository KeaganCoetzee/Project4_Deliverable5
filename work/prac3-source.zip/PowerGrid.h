#ifndef POWERGRID_H
#define POWERGRID_H

#include "Subject.h"

/**
 * @class PowerGrid
 * @brief Concrete Subject managing electrical power status across festival zones.
 */

class PowerGrid : public Subject {
private:
    /** Indicates whether electrical power is operational. */
    bool powerOnline;

public:
    /**
     * @brief Default constructor initializing power to online.
     */
    PowerGrid();

    /**
     * @brief Updates power status and notifies attached electronic components.
     * @param state Boolean flag representing power status (true = online, false = offline).
     */
    void setPowerState(bool state);

    /**
     * @brief Checks if electrical power is active.
     * @return True if power is online, false otherwise.
     */
    bool isOnline() const;
};

#endif