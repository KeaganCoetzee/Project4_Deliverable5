#include "FoodVendor.h"
#include "WeatherMonitor.h"
#include <iostream>

FoodVendor::FoodVendor(std::string name, int capacity, Status status, WeatherMonitor* monitor)
    : EventUnit(name, capacity, status, monitor) {}

void FoodVendor::open() { 
    status = Status::OPEN; 
}

void FoodVendor::close() { 
    status = Status::CLOSED; 
}

int FoodVendor::getCapacity() const { 
    return capacity; 
}

void FoodVendor::reportStatus() const {
    std::cout << "Food Vendor: " << name << " | Capacity: " << capacity << std::endl;
}

void FoodVendor::update() {
    if (weatherMonitor != nullptr) {
        int rain = weatherMonitor->getRainProbability();
        if (rain > 85 && status == Status::OPEN) {
            std::cout << "[ALERT] Food Vendor " << name << " shutting down grills. Paused!" << std::endl;
            status = Status::PAUSED;
        } else if (rain <= 85 && status == Status::PAUSED) {
            std::cout << "[ALERT] Food Vendor " << name << " firing up grills. Resuming!" << std::endl;
            status = Status::OPEN;
        }
    }
}

void FoodVendor::triggerEvacuation() {
    status = Status::CLOSED;
    std::cout << "[EMERGENCY] " << name << " shutting down gas lines and closing." << std::endl;
}