#include "SecurityTeam.h"
#include "Area.h"
#include <stdexcept>

//Concrete Colleague

SecurityTeam::SecurityTeam(const std::string& callSign) : ResponseComponent("Security " + callSign), location(nullptr) {}

SecurityTeam::~SecurityTeam() {}

void SecurityTeam::dispatchTo(Area& area, const std::string& incidentRef) {
    if (location != nullptr) {
        throw std::logic_error(getName() + " is already deployed at " + location->getName());
    }
    location = &area;
    incident = incidentRef;
    log("Dispatched to " + area.getName() + " for incident " + incidentRef);
}

void SecurityTeam::moveTo(Area& area, const std::string& incidentRef) {
    if (location != nullptr && location != &area) {
        log("Reassigned from " + location->getName() + " (" + incident + ") to " + area.getName());
    }
    location = &area;
    incident = incidentRef;
}

void SecurityTeam::manageCrowd(Area& area, const std::string& incidentRef) {
    moveTo(area, incidentRef);
    log("Setting up crowd control at " + area.getName());
}

void SecurityTeam::secureArea(Area& area, const std::string& incidentRef) {
    moveTo(area, incidentRef);
    log("Securing perimeter around " + area.getName());
    notifyCoordinator(CoordinationEvent(EventType::AreaSecured, &area, incidentRef));
}

void SecurityTeam::standDown(const std::string& incidentRef) {
    if (location == nullptr) {
        log("Stand-down ignored: team is not deployed");
        return;
    }
    if (incident != incidentRef) {
        log("Stand-down for " + incidentRef + " ignored: team is now on " + incident);
        return;
    }
    log("Standing down from " + location->getName());
    location = nullptr;
    incident.clear();
}

bool SecurityTeam::isAvailable() const {
    return location == nullptr;
}

std::string SecurityTeam::status() const {
    if (isAvailable()) return "available";
    return "deployed at " + location->getName() +
        (incident.empty() ? "" : " (" + incident + ")");
}
