#ifndef FACILITIESTEAM_H
#define FACILITIESTEAM_H

#include "ResponseComponent.h"

class Area;

// Mediator pattern - Concrete Colleague
class FacilitiesTeam : public ResponseComponent {
public:
    FacilitiesTeam();
    virtual ~FacilitiesTeam();

    void holdLift(Area& area);
    void releaseLift();
    void inspect(Area& area);
    void reportHazard(Area& area, const std::string& incidentRef, const std::string& description);  // notifies HazardReported

    virtual std::string status() const override;

private:
    Area* liftHeldAt;        // Does not own
    Area* inspecting;        // Does not own
};

#endif
