#ifndef RESPONSEMEDIATOR_H
#define RESPONSEMEDIATOR_H

#include "CoordinationEvent.h"

class ResponseComponent;

// Mediator pattern - Abstract Mediator
class ResponseMediator {
public:
    virtual ~ResponseMediator() {}
    virtual void notify(ResponseComponent& sender, const CoordinationEvent& event) = 0;
};

#endif
