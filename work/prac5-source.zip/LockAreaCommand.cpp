#include "LockAreaCommand.h"
#include "AccessController.h"
#include "Area.h"

LockAreaCommand::LockAreaCommand(AccessController& controller, Area& area)
    : controller(controller), area(area), executed(false)
{
}

void LockAreaCommand::execute()
{
    executed = controller.lock(area);
}

void LockAreaCommand::undo()
{
    if (executed)
    {
        controller.unlock(area);
        executed = false;
    }
}