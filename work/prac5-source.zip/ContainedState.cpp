#include "ContainedState.h"
#include "Incident.h"
#include "ResolvedState.h"
#include "CancelledState.h"

#include <iostream>

void ContainedState::dispatch(Incident*)
{
    std::cout << "Incident has already been dispatched." << std::endl;
}

void ContainedState::contain(Incident*)
{
    std::cout << "Incident is already contained." << std::endl;
}

void ContainedState::resolve(Incident* incident)
{
    incident->setState(new ResolvedState());
}

void ContainedState::cancel(Incident* incident)
{
    incident->setState(new CancelledState());
}

std::string ContainedState::getName() const
{
    return "Contained";
}