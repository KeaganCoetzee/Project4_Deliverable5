#include "FacilitiesTeam.h"
#include "Area.h"

//Concrete Colleague

FacilitiesTeam::FacilitiesTeam() : ResponseComponent("Facilities"), liftHeldAt(nullptr), inspecting(nullptr) {}

FacilitiesTeam::~FacilitiesTeam() {}

void FacilitiesTeam::holdLift(Area& area) {
    liftHeldAt = &area;
    log("Holding service lift for responders at " + area.getName());
}

void FacilitiesTeam::releaseLift() {
    if (liftHeldAt == nullptr) {
        log("No lift is currently being held");
        return;
    }
    log("Releasing service lift at " + liftHeldAt->getName());
    liftHeldAt = nullptr;
}

void FacilitiesTeam::inspect(Area& area) {
    inspecting = &area;
    log("Starting hazard inspection in " + area.getName());
}

void FacilitiesTeam::reportHazard(Area& area, const std::string& incidentRef, const std::string& description) {
    log("HAZARD at " + area.getName() + ": " + description);
    notifyCoordinator(CoordinationEvent(EventType::HazardReported, &area, incidentRef, description));
}

std::string FacilitiesTeam::status() const {
    std::string s;
    s += liftHeldAt ? "holding lift at " + liftHeldAt->getName() : "no lift held";
    if (inspecting) s += "; inspecting " + inspecting->getName();
    return s;
}
