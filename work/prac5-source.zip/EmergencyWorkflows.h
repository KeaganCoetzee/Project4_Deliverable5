#ifndef EMERGENCYWORKFLOWS_H
#define EMERGENCYWORKFLOWS_H

class Area;
class Incident;
class AccessController;
class SecurityTeam;

// Facade Pattern
class EmergencyWorkflows
{
public:
    EmergencyWorkflows(AccessController& accessController, SecurityTeam& securityTeam);
    ~EmergencyWorkflows() = default;

    void evacuateBuilding(Area& building, Incident& incident);

private:
    AccessController& accessController;
    SecurityTeam& securityTeam;
};

#endif