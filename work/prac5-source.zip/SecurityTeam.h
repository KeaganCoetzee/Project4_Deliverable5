#ifndef SECURITYTEAM_H
#define SECURITYTEAM_H

#include "ResponseComponent.h"

class Area;

// Mediator pattern - Concrete Colleague
class SecurityTeam : public ResponseComponent {
public:
    explicit SecurityTeam(const std::string& callSign);
    virtual ~SecurityTeam();

    void dispatchTo(Area& area, const std::string& incidentRef);  // throws if already deployed
    void manageCrowd(Area& area, const std::string& incidentRef);
    void secureArea(Area& area, const std::string& incidentRef);  // notifies AreaSecured
    void standDown(const std::string& incidentRef);  // only if still on that incident

    bool isAvailable() const;
    virtual std::string status() const override;

private:
    void moveTo(Area& area, const std::string& incidentRef);

    Area* location;          // Does not own and is null when available
    std::string incident;
};

#endif
