#include "AccessControlService.h"
#include "AccessController.h"
#include "Area.h"
#include <stdexcept>

//Concrete Colleague
//Adapter Client

AccessControlService::AccessControlService(AccessController* c) : ResponseComponent("Access Control"), controller(c), failedRequests(0) {
    if (controller == nullptr) {
        throw std::invalid_argument("AccessControlService needs a door controller");
    }
}

AccessControlService::~AccessControlService() {}

bool AccessControlService::lockArea(Area& area) {
    log("Lock requested for " + area.getName());
    return report(controller->lock(area), "lock", area);
}

bool AccessControlService::unlockArea(Area& area) {
    log("Unlock requested for " + area.getName());
    return report(controller->unlock(area), "unlock", area);
}

bool AccessControlService::restrictArea(Area& area) {
    log("Restriction requested for " + area.getName());
    return report(controller->restrictAccess(area), "restrict", area);
}

bool AccessControlService::report(bool succeeded, const std::string& action, const Area& area) {
    if (!succeeded) {
        ++failedRequests;
        log("FAILED to " + action + " " + area.getName() + " - door controller rejected the request");
    }
    return succeeded;
}

std::string AccessControlService::status() const {
    return failedRequests == 0 ? "online" : "online (" + std::to_string(failedRequests) + " failed request(s))";
}
