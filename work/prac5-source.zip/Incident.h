#ifndef INCIDENT_H
#define INCIDENT_H

#include <string>

class IncidentState;

class Incident
{
public:
    Incident(const std::string& reference, const std::string& description);
    ~Incident();

    Incident(const Incident&) = delete;
    Incident& operator=(const Incident&) = delete;

    void dispatch();
    void contain();
    void resolve();
    void cancel();

    void setState(IncidentState* newState);

    const std::string& getReference() const;
    const std::string& getDescription() const;
    std::string getStateName() const;

private:
    std::string reference;
    std::string description;
    IncidentState* state;
};

#endif