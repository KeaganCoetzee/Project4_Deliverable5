#include "EmergencyWorkflows.h"
#include "Area.h"
#include "Incident.h"
#include "AccessController.h"
#include "SecurityTeam.h"

#include <iostream>

//Facade

EmergencyWorkflows::EmergencyWorkflows(AccessController& accessController, SecurityTeam& securityTeam)
    : accessController(accessController),
      securityTeam(securityTeam)
{
}

void EmergencyWorkflows::evacuateBuilding(Area& building, Incident& incident)
{
    std::cout << "\n=== INITIATING BUILDING EVACUATION ===\n";

    //issue an alert
    std::cout << "1. Issuing emergency evacuation alert...\n";
    std::cout << "   [ALERT PA SYSTEM] All personnel must evacuate " << building.getName() << " immediately!\n";

    //unlock all exits through the Composite and the Adapter
    std::cout << "2. Unlocking all exits in the building...\n";
    accessController.unlock(building);

    //dispatch security
    std::cout << "3. Dispatching security team to manage the evacuation...\n";
    //check if security is already handling subsystem
    if (securityTeam.isAvailable()) {
        securityTeam.dispatchTo(building, incident.getReference());
    } else {
        std::cout << "   [System] Security team is currently busy, routing nearest available unit.\n";
    }

    //update the incident's state
    std::cout << "4. Updating incident status...\n";
    incident.dispatch(); 

    std::cout << "=== EVACUATION WORKFLOW COMPLETE ===\n\n";
}