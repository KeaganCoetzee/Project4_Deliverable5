#ifndef AREA_H
#define AREA_H

#include <string>
#include <vector>

// Composite pattern - Component.
// Access actions can be applied to a single room or a whole building through the same interface.

enum class AccessState { Open, Locked, Restricted };
std::string toString(AccessState state);

class Area {
public:
    explicit Area(const std::string& name);
    virtual ~Area();

    Area(const Area&) = delete;
    Area& operator=(const Area&) = delete;

    const std::string& getName() const;

    // Access operations
    virtual void lock() = 0;
    virtual void unlock() = 0;
    virtual void restrictAccess() = 0;

    // Used by the door-controller adapter to find which hardware to address
    virtual void collectControllerIds(std::vector<int>& ids) const = 0;

    virtual void print(int depth = 0) const = 0;

    virtual void add(Area* child);
    virtual Area* remove(const std::string& childName);
    virtual Area* find(const std::string& areaName);

protected:
    std::string name;
};

#endif
