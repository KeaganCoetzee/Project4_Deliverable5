#include "Zone.h"
#include <algorithm>
#include <iostream>
#include <stdexcept>

//Composite

Zone::Zone(const std::string& zoneName, const std::string& zoneKind) : Area(zoneName), kind(zoneKind) {}

Zone::~Zone() {
    for (Area* child : children) {
        delete child;
    }
}

void Zone::lock() {
    std::cout << "    [Zone] Locking " << kind << " '" << name << "'\n";
    for (Area* child : children) child->lock();
}

void Zone::unlock() {
    std::cout << "    [Zone] Unlocking " << kind << " '" << name << "'\n";
    for (Area* child : children) child->unlock();
}

void Zone::restrictAccess() {
    std::cout << "    [Zone] Restricting " << kind << " '" << name << "'\n";
    for (Area* child : children) child->restrictAccess();
}

void Zone::collectControllerIds(std::vector<int>& ids) const {
    for (const Area* child : children) child->collectControllerIds(ids);
}

void Zone::print(int depth) const {
    std::cout << std::string(depth * 2, ' ') << kind << ": " << name << "\n";
    for (const Area* child : children) child->print(depth + 1);
}

void Zone::add(Area* child) {
    if (child == nullptr) {
        throw std::invalid_argument("Cannot add a null area to '" + name + "'");
    }
    if (child == this) {
        throw std::invalid_argument("'" + name + "' cannot contain itself");
    }
    if (std::find(children.begin(), children.end(), child) != children.end()) {
        throw std::invalid_argument("'" + child->getName() + "' is already inside '" + name + "'");
    }
    children.push_back(child);  // Zone now owns child
}

Area* Zone::remove(const std::string& childName) {
    for (std::vector<Area*>::iterator it = children.begin(); it != children.end(); ++it) {
        if ((*it)->getName() == childName) {
            Area* removed = *it;
            children.erase(it);
            return removed;     // caller now owns child
        }
    }
    return nullptr;
}

Area* Zone::find(const std::string& areaName) {
    if (areaName == name) return this;
    for (Area* child : children) {
        Area* match = child->find(areaName);
        if (match != nullptr) return match;
    }
    return nullptr;
}

const std::string& Zone::getKind() const {
    return kind;
}

std::size_t Zone::childCount() const {
    return children.size();
}
