#include "MedicalTeam.h"
#include "Area.h"
#include <stdexcept>

//Concrete Colleague

MedicalTeam::MedicalTeam(const std::string& unitName) : ResponseComponent("Medical " + unitName), phase(Phase::Available), location(nullptr) {}

MedicalTeam::~MedicalTeam() {}

void MedicalTeam::dispatchTo(Area& area, const std::string& incidentRef) {
    if (phase != Phase::Available) {
        throw std::logic_error(getName() + " is busy with incident " + incident);
    }
    phase = Phase::EnRoute;
    location = &area;
    incident = incidentRef;
    log("En route to " + area.getName() + " for incident " + incidentRef);
}

void MedicalTeam::arriveOnScene(const std::string& situation) {
    if (phase != Phase::EnRoute) {
        throw std::logic_error(getName() + " cannot arrive on scene: it has not been dispatched");
    }
    phase = Phase::OnScene;
    log("Arrived at " + location->getName() + ": " + situation);
    notifyCoordinator(CoordinationEvent(EventType::OnSceneNeedsRoute, location, incident, situation));
}

void MedicalTeam::stabilisePatient() {
    if (phase != Phase::OnScene) {
        throw std::logic_error(getName() + " cannot stabilise a patient: not on scene");
    }
    log("Patient stabilised, transporting from " + location->getName());

    CoordinationEvent event(EventType::CasualtyStabilised, location, incident);
    phase = Phase::Available;
    location = nullptr;
    incident.clear();
    notifyCoordinator(event);
}

bool MedicalTeam::isAvailable() const {
    return phase == Phase::Available;
}

std::string MedicalTeam::status() const {
    switch (phase) {
    case Phase::Available:
        return "available";
    case Phase::EnRoute:
        return "en route to " + location->getName() + " (" + incident + ")";
    case Phase::OnScene:
        return "on scene at " + location->getName() + " (" + incident + ")";
    }
    return "unknown";
}
