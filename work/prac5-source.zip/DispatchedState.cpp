#include "DispatchedState.h"
#include "Incident.h"
#include "ContainedState.h"
#include "CancelledState.h"

#include <iostream>

void DispatchedState::dispatch(Incident*)
{
    std::cout << "Incident has already been dispatched." << std::endl;
}

void DispatchedState::contain(Incident* incident)
{
    incident->setState(new ContainedState());
}

void DispatchedState::resolve(Incident*)
{
    std::cout << "Cannot resolve an incident before it is contained." << std::endl;
}

void DispatchedState::cancel(Incident* incident)
{
    incident->setState(new CancelledState());
}

std::string DispatchedState::getName() const
{
    return "Dispatched";
}