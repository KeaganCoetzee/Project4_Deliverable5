#ifndef ACCESSCONTROLSERVICE_H
#define ACCESSCONTROLSERVICE_H

#include "ResponseComponent.h"

class Area;
class AccessController;

// Mediator pattern - Concrete Colleague
// Talks to door hardware only through the AccessController interface, so it never knows it is really using the legacy system (Adapter).
class AccessControlService : public ResponseComponent {
public:
    explicit AccessControlService(AccessController* controller);  // Does not own and must not be null
    virtual ~AccessControlService();

    bool lockArea(Area& area);
    bool unlockArea(Area& area);
    bool restrictArea(Area& area);

    virtual std::string status() const override;

private:
    bool report(bool succeeded, const std::string& action, const Area& area);

    AccessController* controller;  // Does not own
    int failedRequests;
};

#endif
