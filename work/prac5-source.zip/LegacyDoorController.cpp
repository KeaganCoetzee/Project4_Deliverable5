#include "LegacyDoorController.h"
#include <iostream>

LegacyDoorController::LegacyDoorController() {}

LegacyDoorController::~LegacyDoorController() {}

bool LegacyDoorController::sendCode(int zoneId, char opCode) {
    std::cout << "    [LegacySystem] Hardware ID " << zoneId << " received OP: " << opCode << "\n";
    return true; 
}