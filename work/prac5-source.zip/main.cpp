#include <iostream>
#include <memory>

// Composite Pattern
#include "Zone.h"
#include "Room.h"

// Adapter Pattern
#include "LegacyDoorController.h"
#include "DoorControllerAdapter.h"

// Mediator Pattern
#include "AccessControlService.h"
#include "SecurityTeam.h"
#include "MedicalTeam.h"
#include "FacilitiesTeam.h"
#include "IncidentCoordinator.h"

// Command Pattern
#include "OperatorConsole.h"
#include "LockAreaCommand.h"
#include "RestrictAreaCommand.h"
#include "DispatchUnitCommand.h"

// State Pattern
#include "Incident.h"

// Facade Pattern
#include "EmergencyWorkflows.h"

int main()
{
    std::cout << "========================================================\n";
    std::cout << "     CAMPUS GUARD SYSTEM INITIALIZATION\n";
    std::cout << "========================================================\n";

    Zone* campus = new Zone("Main Campus", "Campus");
    
    Zone* engineering = new Zone("Engineering Building", "Building");
    engineering->add(new Room("Heavy Machinery Lab", 101));
    engineering->add(new Room("Computer Lab 3", 102));
    
    Zone* library = new Zone("Central Library", "Building");
    library->add(new Room("Reading Room A", 201));
    library->add(new Room("Archive", 202));
    
    campus->add(engineering);
    campus->add(library);

    //create to adapt to old legacy doors
    DoorControllerAdapter adapter(new LegacyDoorController());
    //create and pass it in the &adapter, now whenever you need to unlock a building it tells the adapter and it translates to hardware signals
    AccessControlService access(&adapter);
    
    //creating response teams
    SecurityTeam security("Alpha");
    MedicalTeam medical("Med-1");
    FacilitiesTeam facilities; 
    
    //Mediator setup, coordinator
    IncidentCoordinator coordinator(security, medical, facilities, access);
    security.setMediator(&coordinator);
    medical.setMediator(&coordinator);
    facilities.setMediator(&coordinator);
    access.setMediator(&coordinator);
    
    //creating facade, pre-packaged multi step emergency routine, can evacuate building with single method call
    EmergencyWorkflows facade(adapter, security);
    
    //command center console used by operator,Invoker, recieves command objects and executes them and keeps a log history
    OperatorConsole console;


    std::cout << "\n========================================================\n";
    std::cout << "   Situation 1:  Lab Fire in Engineering building\n";
    std::cout << "========================================================\n";

    //State Pattern: incident begins in reportedState
    Incident fireIncident("FIRE-001", "Chemical fire in Heavy Machinery Lab");
    std::cout << "[State] Incident created: " << fireIncident.getStateName() << "\n";
    
    //Facade Pattern: coordinates Alert, Adapter unlocks, Security dispatch, and State update in one call
    facade.evacuateBuilding(*engineering, fireIncident);
    
    std::cout << "[State] Incident is now: " << fireIncident.getStateName() << "\n";
    
    std::cout << "\nResolving the fire incident --\n";
    fireIncident.contain();
    fireIncident.resolve();

    // Stand down security after Situation 1 so they are available for redeployment in Situation 2
    std::cout << "\n-- Standing down security team following incident resolution --\n";
    security.standDown(fireIncident.getReference());


    std::cout << "\n========================================================\n";
    std::cout << "       Situation 2: Medical emergency in the library\n";
    std::cout << "========================================================\n";

    Incident medIncident("MED-002", "Student collapsed in reading room A");
    std::cout << "[State] Incident created: " << medIncident.getStateName() << "\n";
    
    // Command Pattern: dispatch security via encapsulating command
    std::cout << "\n-- Operator issues dispatch command --\n";
    console.executeCommand(std::unique_ptr<Command>(new DispatchUnitCommand(security, *library, medIncident.getReference())
    ));
    medIncident.dispatch(); //state transition

    //Triggering Mediator Coordination
    std::cout << "\n-- Security secures perimeter (Triggers Mediator) --\n";
    security.secureArea(*library, medIncident.getReference());

    std::cout << "\n-- Medical Team arrives (Triggers Mediator) --\n";
    medical.dispatchTo(*library, medIncident.getReference());
    //triggers OnSceneNeedsRoute
    medical.arriveOnScene("Patient unconscious, requires immediate evac route");
    
    // Command(Undo feature): Operator locks down the library...Shouldnt
    std::cout << "\n--Operator makes a mistake and issues lockdown command --\n";
    console.executeCommand(std::unique_ptr<Command>(new LockAreaCommand(adapter, *library)));
    
    std::cout << "\n-- Operator realizes mistake and uses UNDO --\n";
    console.undoLastCommand();

    //Command: operator restricts area to responders only
    std::cout << "\n-- Operator restricts the area instead --\n";
    console.executeCommand(std::unique_ptr<Command>(new RestrictAreaCommand(adapter, *library)));
    
    // Medical resolution: triggers Mediator to release lifts 
    std::cout << "\n-- Medical team resolves scene --\n";
    medical.stabilisePatient();
    medIncident.contain();
    medIncident.resolve();
    
    // State Pattern: Demonstrating an invalid transition handled gracefully
    std::cout << "\n-- Demonstrating Invalid State Transition --\n";
    std::cout << "Attempting to cancel an already resolved incident:\n";
    medIncident.cancel(); 


    std::cout << "\n========================================================\n";
    std::cout << "            SYSTEM SHUTDOWN\n";
    std::cout << "========================================================\n";
    
    delete campus; 
    
    return 0;
}