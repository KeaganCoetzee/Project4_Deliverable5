#include "OperatorConsole.h"

void OperatorConsole::executeCommand(std::unique_ptr<Command> command)
{
    command->execute();
    history.push_back(std::move(command));
}

void OperatorConsole::undoLastCommand()
{
    if (!history.empty())
    {
        history.back()->undo();
        history.pop_back();
    }
}