#include "IncidentCoordinator.h"
#include "SecurityTeam.h"
#include "MedicalTeam.h"
#include "FacilitiesTeam.h"
#include "AccessControlService.h"
#include "Area.h"
#include <iostream>
#include <stdexcept>

//Concrete Mediator

IncidentCoordinator::IncidentCoordinator(SecurityTeam& s, MedicalTeam& m, FacilitiesTeam& f, AccessControlService& a)
    : security(s), medical(m), facilities(f), access(a) {
    security.setMediator(this);
    medical.setMediator(this);
    facilities.setMediator(this);
    access.setMediator(this);
}

IncidentCoordinator::~IncidentCoordinator() {
    security.setMediator(nullptr);
    medical.setMediator(nullptr);
    facilities.setMediator(nullptr);
    access.setMediator(nullptr);
}

void IncidentCoordinator::notify(ResponseComponent& sender, const CoordinationEvent& event) {
    if (event.location == nullptr) {
        throw std::invalid_argument("Coordination event from " + sender.getName() + " has no location");
    }

    std::cout << "  >> [Coordinator] " << sender.getName() << " reported "
        << toString(event.type) << " at " << event.location->getName()
        << " (" << event.incidentRef << ")\n";

    switch (event.type) {
    case EventType::OnSceneNeedsRoute:
        handleRouteRequest(event);
        break;
    case EventType::HazardReported:
        handleHazard(event);
        break;
    case EventType::AreaSecured:
        handleAreaSecured(event);
        break;
    case EventType::CasualtyStabilised:
        handleCasualtyStabilised(event);
        break;
    }
}

// Medical team is on scene: clear the way in and keep bystanders back
void IncidentCoordinator::handleRouteRequest(const CoordinationEvent& event) {
    std::cout << "  >> [Coordinator] Clearing a route for medical responders\n";
    Area& scene = *event.location;
    access.unlockArea(scene);
    facilities.holdLift(scene);
    security.manageCrowd(scene, event.incidentRef);
}

// Hazard found: keep people out and get security to secure the perimeter
void IncidentCoordinator::handleHazard(const CoordinationEvent& event) {
    std::cout << "  >> [Coordinator] Containing hazard: " << event.detail << "\n";
    access.restrictArea(*event.location);
    security.secureArea(*event.location, event.incidentRef);
}

// Perimeter is safe: facilities can now go in and inspect
void IncidentCoordinator::handleAreaSecured(const CoordinationEvent& event) {
    std::cout << "  >> [Coordinator] Perimeter secure, sending in facilities\n";
    facilities.inspect(*event.location);
}

// Patient has left the scene: release resources held for the response
void IncidentCoordinator::handleCasualtyStabilised(const CoordinationEvent& event) {
    std::cout << "  >> [Coordinator] Medical response complete, releasing resources\n";
    facilities.releaseLift();
    security.standDown(event.incidentRef);
}

void IncidentCoordinator::printStatusBoard() const {
    std::cout << "  ---- Response status board ----\n";
    std::cout << "  " << security.getName() << ": " << security.status() << "\n";
    std::cout << "  " << medical.getName() << ": " << medical.status() << "\n";
    std::cout << "  " << facilities.getName() << ": " << facilities.status() << "\n";
    std::cout << "  " << access.getName() << ": " << access.status() << "\n";
}
