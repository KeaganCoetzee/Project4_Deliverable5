#include "Incident.h"
#include "IncidentState.h"
#include "ReportedState.h"

Incident::Incident(const std::string& reference, const std::string& description)
    : reference(reference),
      description(description),
      state(new ReportedState())
{
}

Incident::~Incident()
{
    delete state;
}

void Incident::dispatch()
{
    state->dispatch(this);
}

void Incident::contain()
{
    state->contain(this);
}

void Incident::resolve()
{
    state->resolve(this);
}

void Incident::cancel()
{
    state->cancel(this);
}

void Incident::setState(IncidentState* newState)
{
    delete state;
    state = newState;
}

const std::string& Incident::getReference() const
{
    return reference;
}

const std::string& Incident::getDescription() const
{
    return description;
}

std::string Incident::getStateName() const
{
    return state->getName();
}