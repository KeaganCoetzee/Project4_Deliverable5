#ifndef INCIDENTCOORDINATOR_H
#define INCIDENTCOORDINATOR_H

#include "ResponseMediator.h"

class SecurityTeam;
class MedicalTeam;
class FacilitiesTeam;
class AccessControlService;

// Mediator pattern - Concrete Mediator
// The coordinator does NOT own the components
// It must be destroyed before them (declared after them), because its destructor detaches itself from each component
class IncidentCoordinator : public ResponseMediator {
public:
    IncidentCoordinator(SecurityTeam& security, MedicalTeam& medical, FacilitiesTeam& facilities, AccessControlService& access);
    virtual ~IncidentCoordinator();

    IncidentCoordinator(const IncidentCoordinator&) = delete;
    IncidentCoordinator& operator=(const IncidentCoordinator&) = delete;

    virtual void notify(ResponseComponent& sender, const CoordinationEvent& event) override;

    void printStatusBoard() const;

private:
    void handleRouteRequest(const CoordinationEvent& event);
    void handleHazard(const CoordinationEvent& event);
    void handleAreaSecured(const CoordinationEvent& event);
    void handleCasualtyStabilised(const CoordinationEvent& event);

    SecurityTeam& security;
    MedicalTeam& medical;
    FacilitiesTeam& facilities;
    AccessControlService& access;
};

#endif
