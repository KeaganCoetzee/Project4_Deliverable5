#ifndef CANCELLEDSTATE_H
#define CANCELLEDSTATE_H

#include "IncidentState.h"

class CancelledState : public IncidentState
{
public:
    void dispatch(Incident* incident) override;
    void contain(Incident* incident) override;
    void resolve(Incident* incident) override;
    void cancel(Incident* incident) override;

    std::string getName() const override;
};

#endif