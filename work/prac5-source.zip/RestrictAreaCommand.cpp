#include "RestrictAreaCommand.h"
#include "AccessController.h"
#include "Area.h"

RestrictAreaCommand::RestrictAreaCommand(AccessController& controller, Area& area)
    : controller(controller), area(area), executed(false)
{
}

void RestrictAreaCommand::execute()
{
    executed = controller.restrictAccess(area);
}

void RestrictAreaCommand::undo()
{
    if (executed)
    {
        controller.unlock(area);
        executed = false;
    }
}