#ifndef ACCESSCONTROLLER_H
#define ACCESSCONTROLLER_H

class Area;

class AccessController {
public:
    virtual ~AccessController() {}

    virtual bool lock(Area& area) = 0;
    virtual bool unlock(Area& area) = 0;
    virtual bool restrictAccess(Area& area) = 0;
};

#endif