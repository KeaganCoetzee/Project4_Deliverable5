#include "ReportedState.h"
#include "Incident.h"
#include "DispatchedState.h"
#include "CancelledState.h"

#include <iostream>

void ReportedState::dispatch(Incident* incident)
{
    incident->setState(new DispatchedState());
}

void ReportedState::contain(Incident*)
{
    std::cout << "Cannot contain an incident that has not been dispatched." << std::endl;
}

void ReportedState::resolve(Incident*)
{
    std::cout << "Cannot resolve an incident that has not been dispatched." << std::endl;
}

void ReportedState::cancel(Incident* incident)
{
    incident->setState(new CancelledState());
}

std::string ReportedState::getName() const
{
    return "Reported";
}