#ifndef MEDICALTEAM_H
#define MEDICALTEAM_H

#include "ResponseComponent.h"

class Area;

// Mediator pattern - Concrete Colleague
class MedicalTeam : public ResponseComponent {
public:
    explicit MedicalTeam(const std::string& unitName);
    virtual ~MedicalTeam();

    void dispatchTo(Area& area, const std::string& incidentRef);  // throws if busy
    void arriveOnScene(const std::string& situation);            // notifies OnSceneNeedsRoute
    void stabilisePatient();                                     // notifies CasualtyStabilised

    bool isAvailable() const;
    virtual std::string status() const override;

private:
    enum class Phase { Available, EnRoute, OnScene };

    Phase phase;
    Area* location;          // Does not own
    std::string incident;
};

#endif
