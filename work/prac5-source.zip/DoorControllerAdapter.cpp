#include "DoorControllerAdapter.h"
#include "LegacyDoorController.h"
#include "Area.h"
#include <vector>
#include <stdexcept>

DoorControllerAdapter::DoorControllerAdapter(LegacyDoorController* legacySystem) 
    : legacySystem(legacySystem) {
    if (!this->legacySystem) {
        throw std::invalid_argument("DoorControllerAdapter needs a valid LegacyDoorController");
    }
}

DoorControllerAdapter::~DoorControllerAdapter() {
    delete legacySystem;
}

bool DoorControllerAdapter::lock(Area& area) {
    area.lock();
    return executeLegacyCommand(area, 'L');
}

bool DoorControllerAdapter::unlock(Area& area) {
    area.unlock();
    return executeLegacyCommand(area, 'U');
}

bool DoorControllerAdapter::restrictAccess(Area& area) {
    area.restrictAccess();
    return executeLegacyCommand(area, 'R');
}

bool DoorControllerAdapter::executeLegacyCommand(Area& area, char opCode) {
    std::vector<int> hardwareIds;
    area.collectControllerIds(hardwareIds);

    bool allSucceeded = true;
    for (int id : hardwareIds) {
        if (!legacySystem->sendCode(id, opCode)) {
            allSucceeded = false;
        }
    }
    
    return allSucceeded;
}