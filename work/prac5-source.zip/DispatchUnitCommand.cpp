#include "DispatchUnitCommand.h"
#include "SecurityTeam.h"
#include "Area.h"

DispatchUnitCommand::DispatchUnitCommand(SecurityTeam& unit,
                                         Area& area,
                                         const std::string& incidentRef)
    : unit(unit),
      area(area),
      incidentRef(incidentRef),
      executed(false)
{
}

void DispatchUnitCommand::execute()
{
    unit.dispatchTo(area, incidentRef);
    executed = true;
}

void DispatchUnitCommand::undo()
{
    if (executed)
    {
        unit.standDown(incidentRef);
        executed = false;
    }
}