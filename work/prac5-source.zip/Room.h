#ifndef ROOM_H
#define ROOM_H

#include "Area.h"

// Composite pattern - Leaf.
class Room : public Area {
public:
    Room(const std::string& name, int controllerId);
    virtual ~Room();

    virtual void lock() override;
    virtual void unlock() override;
    virtual void restrictAccess() override;
    virtual void collectControllerIds(std::vector<int>& ids) const override;
    virtual void print(int depth = 0) const override;

    AccessState getState() const;
    int getControllerId() const;

private:
    int controllerId;
    AccessState state;
};

#endif
