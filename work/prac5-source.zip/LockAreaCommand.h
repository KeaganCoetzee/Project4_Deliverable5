#ifndef LOCKAREACOMMAND_H
#define LOCKAREACOMMAND_H

#include "Command.h"

class AccessController;
class Area;

class LockAreaCommand : public Command
{
public:
    LockAreaCommand(AccessController& controller, Area& area);

    void execute() override;
    void undo() override;

private:
    AccessController& controller;
    Area& area;
    bool executed;
};

#endif