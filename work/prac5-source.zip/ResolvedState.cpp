#include "ResolvedState.h"
#include "Incident.h"

#include <iostream>

void ResolvedState::dispatch(Incident*)
{
    std::cout << "Cannot dispatch a resolved incident." << std::endl;
}

void ResolvedState::contain(Incident*)
{
    std::cout << "Cannot contain a resolved incident." << std::endl;
}

void ResolvedState::resolve(Incident*)
{
    std::cout << "Incident is already resolved." << std::endl;
}

void ResolvedState::cancel(Incident*)
{
    std::cout << "Cannot cancel a resolved incident." << std::endl;
}

std::string ResolvedState::getName() const
{
    return "Resolved";
}