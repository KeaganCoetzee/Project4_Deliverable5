#include "CancelledState.h"
#include "Incident.h"

#include <iostream>

void CancelledState::dispatch(Incident*)
{
    std::cout << "Cannot dispatch a cancelled incident." << std::endl;
}

void CancelledState::contain(Incident*)
{
    std::cout << "Cannot contain a cancelled incident." << std::endl;
}

void CancelledState::resolve(Incident*)
{
    std::cout << "Cannot resolve a cancelled incident." << std::endl;
}

void CancelledState::cancel(Incident*)
{
    std::cout << "Incident is already cancelled." << std::endl;
}

std::string CancelledState::getName() const
{
    return "Cancelled";
}