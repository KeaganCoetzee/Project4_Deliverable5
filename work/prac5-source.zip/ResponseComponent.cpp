#include "ResponseComponent.h"
#include "ResponseMediator.h"
#include <iostream>
#include <stdexcept>

//Abstract Colleague

ResponseComponent::ResponseComponent(const std::string& componentName) : name(componentName), mediator(nullptr) {}

ResponseComponent::~ResponseComponent() {}

void ResponseComponent::setMediator(ResponseMediator* m) {
    mediator = m;
}

bool ResponseComponent::hasMediator() const {
    return mediator != nullptr;
}

const std::string& ResponseComponent::getName() const {
    return name;
}

void ResponseComponent::notifyCoordinator(const CoordinationEvent& event) {
    if (mediator == nullptr) {
        throw std::logic_error(name + " raised '" + toString(event.type) +
            "' but no coordinator is attached");
    }
    mediator->notify(*this, event);
}

void ResponseComponent::log(const std::string& message) const {
    std::cout << "  [" << name << "] " << message << "\n";
}
