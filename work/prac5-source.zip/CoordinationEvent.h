#ifndef COORDINATIONEVENT_H
#define COORDINATIONEVENT_H

#include <string>

class Area;

enum class EventType {
    OnSceneNeedsRoute,   // medical team arrived and needs a clear route
    HazardReported,      // facilities found a dangerous condition
    AreaSecured,         // security has secured a perimeter
    CasualtyStabilised   // medical team is done at the scene
};

inline std::string toString(EventType type) {
    switch (type) {
    case EventType::OnSceneNeedsRoute:
        return "ON SCENE - ROUTE NEEDED";
    case EventType::HazardReported:
        return "HAZARD REPORTED";
    case EventType::AreaSecured:
        return "AREA SECURED";
    case EventType::CasualtyStabilised:
        return "CASUALTY STABILISED";
    }

    return "UNKNOWN EVENT";
}

struct CoordinationEvent {
    EventType type;
    Area* location;          // Does not own
    std::string incidentRef;
    std::string detail;

    CoordinationEvent(EventType t, Area* where, const std::string& ref, const std::string& info = "")
        : type(t), location(where), incidentRef(ref), detail(info) {}
};

#endif
