#ifndef RESTRICTAREACOMMAND_H
#define RESTRICTAREACOMMAND_H

#include "Command.h"

class AccessController;
class Area;

class RestrictAreaCommand : public Command
{
public:
    RestrictAreaCommand(AccessController& controller, Area& area);

    void execute() override;
    void undo() override;

private:
    AccessController& controller;
    Area& area;
    bool executed;
};

#endif