#include "Area.h"
#include <stdexcept>

//Component

std::string toString(AccessState state) {
    switch (state) {
    case AccessState::Open:
        return "OPEN";
    case AccessState::Locked:
        return "LOCKED";
    case AccessState::Restricted:
        return "RESTRICTED";
    }

    return "UNKNOWN";
}

Area::Area(const std::string& areaName) : name(areaName) {}

Area::~Area() {}

const std::string& Area::getName() const {
    return name;
}

void Area::add(Area*) {
    // Child ownership stays with the caller when this throws.
    throw std::logic_error("Cannot add an area inside '" + name + "': it is a single room");
}

Area* Area::remove(const std::string&) {
    return nullptr;
}

Area* Area::find(const std::string& areaName) {
    return areaName == name ? this : nullptr;
}
