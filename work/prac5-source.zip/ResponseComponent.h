#ifndef RESPONSECOMPONENT_H
#define RESPONSECOMPONENT_H

#include <string>
#include "CoordinationEvent.h"

class ResponseMediator;

// Mediator pattern - Abstract Colleague
// Components only know the mediator, never each other.
class ResponseComponent {
public:
    explicit ResponseComponent(const std::string& name);
    virtual ~ResponseComponent();

    ResponseComponent(const ResponseComponent&) = delete;
    ResponseComponent& operator=(const ResponseComponent&) = delete;

    void setMediator(ResponseMediator* mediator);  // Does not own
    bool hasMediator() const;
    const std::string& getName() const;

    virtual std::string status() const = 0;

protected:
    // Throws std::logic_error if no coordinator is attached
    void notifyCoordinator(const CoordinationEvent& event);
    void log(const std::string& message) const;

private:
    std::string name;
    ResponseMediator* mediator;  // Does not own
};

#endif
