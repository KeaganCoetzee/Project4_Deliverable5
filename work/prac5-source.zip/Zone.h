#ifndef ZONE_H
#define ZONE_H

#include "Area.h"
#include <vector>

// Composite pattern - Composite.
// A campus, building or floor that contains other areas.
class Zone : public Area {
public:
    Zone(const std::string& name, const std::string& kind);
    virtual ~Zone();

    virtual void lock() override;
    virtual void unlock() override;
    virtual void restrictAccess() override;
    virtual void collectControllerIds(std::vector<int>& ids) const override;
    virtual void print(int depth = 0) const override;

    virtual void add(Area* child) override;
    virtual Area* remove(const std::string& childName) override;
    virtual Area* find(const std::string& areaName) override;

    const std::string& getKind() const;
    std::size_t childCount() const;

private:
    std::string kind;              // Type eg. "Campus", "Building", "Floor", ...
    std::vector<Area*> children;
};

#endif
