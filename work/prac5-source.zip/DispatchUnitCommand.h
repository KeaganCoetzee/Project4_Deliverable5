#ifndef DISPATCHUNITCOMMAND_H
#define DISPATCHUNITCOMMAND_H

#include "Command.h"
#include <string>

class SecurityTeam;
class Area;

class DispatchUnitCommand : public Command
{
public:
    DispatchUnitCommand(SecurityTeam& unit,
                        Area& area,
                        const std::string& incidentRef);

    void execute() override;
    void undo() override;

private:
    SecurityTeam& unit;
    Area& area;
    std::string incidentRef;
    bool executed;
};

#endif