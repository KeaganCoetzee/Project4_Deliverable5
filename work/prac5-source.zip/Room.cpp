#include "Room.h"
#include <iostream>
#include <stdexcept>

//leaf

Room::Room(const std::string& roomName, int id) : Area(roomName), controllerId(id), state(AccessState::Open) {
    if (id <= 0) {
        throw std::invalid_argument("Room '" + roomName + "' needs a positive door controller id");
    }
}

Room::~Room() {}

void Room::lock() {
    state = AccessState::Locked;
    std::cout << "      - " << name << " locked\n";
}

void Room::unlock() {
    state = AccessState::Open;
    std::cout << "      - " << name << " unlocked\n";
}

void Room::restrictAccess() {
    state = AccessState::Restricted;
    std::cout << "      - " << name << " restricted (responders only)\n";
}

void Room::collectControllerIds(std::vector<int>& ids) const {
    ids.push_back(controllerId);
}

void Room::print(int depth) const {
    std::cout << std::string(depth * 2, ' ') << "Room: " << name
        << " (door #" << controllerId << ") [" << toString(state) << "]\n";
}

AccessState Room::getState() const {
    return state;
}

int Room::getControllerId() const {
    return controllerId;
}
