#ifndef LEGACYDOORCONTROLLER_H
#define LEGACYDOORCONTROLLER_H

class LegacyDoorController {
public:
    LegacyDoorController();
    virtual ~LegacyDoorController();

    bool sendCode(int zoneId, char opCode);
};

#endif