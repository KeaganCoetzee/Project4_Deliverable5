#ifndef DOORCONTROLLERADAPTER_H
#define DOORCONTROLLERADAPTER_H

#include "AccessController.h"

class LegacyDoorController;

class DoorControllerAdapter : public AccessController {
public:

    explicit DoorControllerAdapter(LegacyDoorController* legacySystem);
    virtual ~DoorControllerAdapter();
    DoorControllerAdapter(const DoorControllerAdapter&) = delete;
    DoorControllerAdapter& operator=(const DoorControllerAdapter&) = delete;

    virtual bool lock(Area& area) override;
    virtual bool unlock(Area& area) override;
    virtual bool restrictAccess(Area& area) override;

private:

    bool executeLegacyCommand(Area& area, char opCode);

    LegacyDoorController* legacySystem;
};

#endif