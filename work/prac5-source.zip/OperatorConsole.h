#ifndef OPERATORCONSOLE_H
#define OPERATORCONSOLE_H

#include <memory>
#include <vector>

#include "Command.h"

class OperatorConsole
{
public:
    void executeCommand(std::unique_ptr<Command> command);
    void undoLastCommand();

private:
    std::vector<std::unique_ptr<Command>> history;
};

#endif