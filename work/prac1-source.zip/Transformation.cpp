#include "Transformation.h"
//Prototype Pattern

Transformation::Transformation(std::string name) : name(name) {}

Transformation::~Transformation() {}

std::string Transformation::getName() {
    return name;
}

DeduplicateStep::DeduplicateStep() : Transformation("dedup") {}

DeduplicateStep::DeduplicateStep(const DeduplicateStep& other) : Transformation(other.name) {}

Transformation* DeduplicateStep::clone() {
    return new DeduplicateStep(*this);
}

std::vector<std::string> DeduplicateStep::apply(std::vector<std::string> records) {
    std::vector<std::string> result;
    if (records.empty()) return result;
    
    result.push_back(records[0]);
    
    for (size_t i = 1; i < records.size(); ++i) {
        if (records[i] != records[i - 1]) {
            result.push_back(records[i]);
        }
    }
    return result;
}

AggregateByRegionStep::AggregateByRegionStep() : Transformation("aggregate") {}

AggregateByRegionStep::AggregateByRegionStep(const AggregateByRegionStep& other) : Transformation(other.name) {}

Transformation* AggregateByRegionStep::clone() {
    return new AggregateByRegionStep(*this);
}

std::vector<std::string> AggregateByRegionStep::apply(std::vector<std::string> records) {
    std::vector<std::string> result;
    result.push_back("COUNT=" + std::to_string(records.size()));
    return result;
}