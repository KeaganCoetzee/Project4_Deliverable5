#ifndef TRANSFORMATION_H
#define TRANSFORMATION_H

#include <string>
#include <vector>

//Prototype Pattern

class Transformation{
    protected:
        std::string name;

    public: 
        Transformation(std::string);
        virtual ~Transformation();

        virtual Transformation* clone() = 0;
        virtual std::vector<std::string> apply(std::vector<std::string> records) = 0;
        std::string getName();

};

class DeduplicateStep : public Transformation{
    public: 
        DeduplicateStep();
        DeduplicateStep(const DeduplicateStep& other);

        Transformation* clone() override;
        std::vector<std::string> apply(std::vector<std::string> records) override;

};

class AggregateByRegionStep : public Transformation{
    public:
        AggregateByRegionStep();
        AggregateByRegionStep(const AggregateByRegionStep& other);

        Transformation *clone() override;
        std::vector<std::string> apply(std::vector<std::string> records) override;

};


#endif

//The Prototype: a metal star-shaped cookie cutter
//The Registry: your kitchen draw holding star, circle and heart cutter
//Explanation: when you need a star cookie you dont go out and smelt a brand new one you open the draw(registry) and take the master star cutter and get an exact copy---clone()


