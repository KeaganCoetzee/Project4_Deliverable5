#ifndef RUNCHECKPOINT_H
#define RUNCHECKPOINT_H

#include <vector>
#include <string>
//Memento Pattern

class RunCheckpoint {
private:
    int stage;
    std::vector<std::string> records;

public:
    RunCheckpoint(int stage, std::vector<std::string> records);
    
    int getStage();
    std::vector<std::string> getRecords();
};

#endif

//The Originator: you the reader know what page you are on in a book
// The memento: a physical cardboard bookmark
// Caretaker: the book sitting on your nightstand it holds the bookmark between the bages