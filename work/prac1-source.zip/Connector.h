#ifndef CONNECTOR_H
#define CONNECTOR_H

#include <string>
#include <vector>
//Factory method

class Connector{
    protected:
        std::string source;
    
    public:
        Connector(std::string source);
        virtual ~Connector();

        virtual std::vector<std::string> extract() = 0;
        std::string getSource();
};

class PostgresConnector : public Connector{
    public:
        PostgresConnector();
        std::vector<std::string> extract() override;
};

class RestApiConnector : public Connector{
    public:
        RestApiConnector();
        std::vector<std::string> extract() override;
};

class CsvConnector : public Connector{
    public:
        CsvConnector();
        std::vector<std::string> extract() override;
};

#endif



//The Factory: coffee barista
//Product: flat white, espresso or tea
//Explanation: you dont do any of the work, you simply ask barista for a coffee and they build it and hand you your drink.(you unaware of how it was made)


//The Factory takes the records you give it and creates a product based on the deliveries. And then sends it to the various factories to create the product not even looking at whats inside it.