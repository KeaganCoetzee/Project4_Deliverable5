#include "CheckpointManager.h"
//Memento Pattern

CheckpointManager::CheckpointManager() {}

CheckpointManager::~CheckpointManager() {
    for (RunCheckpoint* cp : history) {
        delete cp;
    }
    history.clear();
}

void CheckpointManager::save(RunCheckpoint* cp) {
    history.push_back(cp);
}

RunCheckpoint* CheckpointManager::undo() {
    if (history.empty()) {
        return nullptr;
    }
    
    RunCheckpoint* lastCheckpoint = history.back();
    history.pop_back();
    return lastCheckpoint;
}