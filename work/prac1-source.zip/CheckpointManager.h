#ifndef CHECKPOINTMANAGER_H
#define CHECKPOINTMANAGER_H

#include <vector>
#include "RunCheckpoint.h"
//Memento Pattern

class CheckpointManager {
private:
    std::vector<RunCheckpoint*> history;

public:
    CheckpointManager();
    ~CheckpointManager();

    void save(RunCheckpoint* cp);
    RunCheckpoint* undo();
};

#endif