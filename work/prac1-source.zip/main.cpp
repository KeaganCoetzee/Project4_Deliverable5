#include <iostream>
#include "ConnectorFactory.h"
#include "Transformation.h"
#include "TransformationRegistry.h"
#include "Pipeline.h"
#include "RunCheckpoint.h"
#include "CheckpointManager.h"

int main() {
    TransformationRegistry* registry = new TransformationRegistry();
    registry->registerStep("dedup", new DeduplicateStep());
    registry->registerStep("aggregate", new AggregateByRegionStep());

    ConnectorFactory* pgFactory = new PostgresFactory();
    Pipeline* pipeline = new BatchPipeline(pgFactory);

    pipeline->addStep(registry->create("dedup"));
    pipeline->addStep(registry->create("aggregate"));

    CheckpointManager* manager = new CheckpointManager();

    pipeline->run();
    RunCheckpoint* cp = pipeline->createCheckpoint();
    manager->save(cp);

    delete pipeline;
    delete registry;
    delete manager;

    std::cout << "Pipeline execution complete. No memory leaks!" << std::endl;

    return 0;
}