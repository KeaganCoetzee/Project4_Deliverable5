#ifndef TRANSFORMATIONREGISTRY_H
#define TRANSFORMATIONREGISTRY_H

#include <string>
#include <map>
#include "Transformation.h"
//Prototype Pattern

class TransformationRegistry {
private:
    std::map<std::string, Transformation*> prototypes;

public:
    TransformationRegistry();
    ~TransformationRegistry();

    void registerStep(std::string key, Transformation* prototype);
    Transformation* create(std::string key);
};

#endif