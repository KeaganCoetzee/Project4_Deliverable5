#include "Connector.h"
//Factory method

Connector::Connector(std::string source) : source(source){}
Connector::~Connector(){}

std::string Connector:: getSource(){
    return source;
}

PostgresConnector:: PostgresConnector() : Connector("postgres"){}
std::vector<std::string> PostgresConnector::extract(){
    return {"PG:001", "PG:002", "PG:002", "PG:003"};
}

RestApiConnector::RestApiConnector() : Connector("restapi") {}
std::vector<std::string> RestApiConnector::extract() {
    return {"API:44", "API:45", "API:45"};
}

CsvConnector::CsvConnector() : Connector("csv") {}
std::vector<std::string> CsvConnector::extract() {
    return {"CSV:x1", "CSV:x2", "CSV:x3", "CSV:x3"};
}