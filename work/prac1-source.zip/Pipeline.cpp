#include "Pipeline.h"
#include "RunCheckpoint.h"
#include <iostream>
//Template Method

Pipeline::Pipeline(ConnectorFactory* factory) : factory(factory), stage(0){}

Pipeline::~Pipeline(){
    delete factory;
    for(Transformation* step : steps){
        delete step;
    }
    steps.clear();
}

void Pipeline::addStep(Transformation* step){
    steps.push_back(step);
}


//Template method
void Pipeline::run(){
    connect();
    extract();
    transform();
    load();
}

//connect()
void Pipeline::connect(){
    Connector* conn = factory->createConnector();
    std::cout << "Connecting to "<< conn->getSource() << "\n";
    stage = 1;
    delete conn;
}

//transform()
void Pipeline::transform(){
    for(Transformation* step : steps){
        records = step->apply(records);
    }
    stage = 3;
}

RunCheckpoint* Pipeline::createCheckpoint() {
    return new RunCheckpoint(stage, records);
}

void Pipeline::restore(RunCheckpoint* cp) {
    if (cp != nullptr) {
        this->stage = cp->getStage();
        this->records = cp->getRecords();
    }
}

//BatchPipeline
BatchPipeline::BatchPipeline(ConnectorFactory* factory) : Pipeline(factory) {}

void BatchPipeline::extract(){
    Connector* conn = factory->createConnector();
    records = conn->extract();
    std::cout << "Batch extract: " << records.size() << " records\n";
    stage = 2;
    delete conn;
}

void BatchPipeline::load() {
    std::cout << "Batch load: " << records.size() << " records written\n";
    stage = 4;
}

//StreamingPipeline 
StreamingPipeline::StreamingPipeline(ConnectorFactory* factory) : Pipeline(factory) {}

void StreamingPipeline::extract() {
    Connector* conn = factory->createConnector();
    records = conn->extract();
    std::cout << "Streaming extract: " << records.size() << " records\n";
    stage = 2;
    delete conn;
}

void StreamingPipeline::load() {
    std::cout << "Streaming load: " << records.size() << " records streamed\n";
    stage = 4;
}