#ifndef PIPELINE_H
#define PIPELINE_H

#include "ConnectorFactory.h"
#include "Transformation.h"
//Template Method

class RunCheckpoint;

class Pipeline{
    protected:  
        ConnectorFactory* factory;
        std::vector<Transformation*> steps;
        int stage;
        std::vector<std::string> records;

        void connect();
        virtual void extract() = 0;
        void transform();
        virtual void load() = 0;
    
    public:
        Pipeline(ConnectorFactory* factory);
        virtual ~Pipeline();

        void addStep(Transformation* step);
        void run();
        RunCheckpoint* createCheckpoint();
        void restore(RunCheckpoint* cp);

};

class BatchPipeline : public Pipeline{
    protected:
        void extract() override;
        void load() override;
    
    public: 
        BatchPipeline(ConnectorFactory* factory);

};

class StreamingPipeline : public Pipeline {
protected:
    void extract() override;
    void load() override;
public:
    StreamingPipeline(ConnectorFactory* factory);
};


#endif


//Building codes for a house: 1)lay foundation  2) build walls  3) put roof on   4) paint
//explanation: strict 1-4 schedule however you can choose the detail, how they build the walls what type of roof or what colour paint


//This has to go in a specific 4 step order, Connect, extract, transform, load. and the connect and transform are the same for both instances of streaming and batch but the extract and load are different leading the different implementations. !!!!TEMPLATE METHOD