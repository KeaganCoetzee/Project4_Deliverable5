#include "TransformationRegistry.h"
//Prototype Pattern

TransformationRegistry::TransformationRegistry() {}

TransformationRegistry::~TransformationRegistry() {
    for (auto const& pair : prototypes) {
        delete pair.second;
    }
    prototypes.clear();
}

void TransformationRegistry::registerStep(std::string key, Transformation* prototype) {
    if (prototypes.find(key) != prototypes.end()) {
        delete prototypes[key];
    }
    prototypes[key] = prototype;
}

Transformation* TransformationRegistry::create(std::string key) {
    if (prototypes.find(key) != prototypes.end()) {
        return prototypes[key]->clone();
    }
    return nullptr; 
}