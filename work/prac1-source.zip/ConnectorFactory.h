#ifndef CONNECTORFACTORY_H
#define CONNECTORFACTORY_H
//Factory Method

#include "Connector.h"

class ConnectorFactory{
    public:
        virtual Connector* createConnector() = 0;
        virtual ~ConnectorFactory();
};

class PostgresFactory : public ConnectorFactory{
    public:
        Connector* createConnector() override;
    
};

class RestApiFactory : public ConnectorFactory{
    public:
        Connector* createConnector() override;

};

class CsvFactory : public ConnectorFactory{
    public:
        Connector* createConnector() override;

};


#endif


//